#include <mutex>
#include <memory>
__int64 TargetedBuild;
bool bTargetedBuild;

namespace Aimbot {
	inline bool triger = 0;
	inline bool aimbot = 1;
	inline bool prediction = 0;
	inline bool visible_check = 1;
	inline bool fov_circle = 1;
	inline bool target_text = 0;
	inline bool target_line;
	inline bool is_dead = 0;
	inline bool in_lobby;

	static int aim_fov = 100;
	static int smooth = 5;




	inline int g_hitbox = 0;
	inline float g_aim_max_dist = 275; // 275

	inline int aimkey = VK_RBUTTON;
	inline int triggerkey = VK_RBUTTON;
	inline int hitbox = 1; // 0 = niekas // 1 galva
}

namespace Fov
{
	inline bool RGB = 0;
	int rainbowSpeed = 2; // Default rainbow speed
	inline bool filled = 0;
}

namespace colors
{
	float watermarkcolor[4] = { 0.f, 1.f, 0.f, 1.f };
	float fov_color[4] = { 1.f, 1.f, 1.f, 0.f };

	float box_visible[4] = { 0.f, 1.f, 0.f, 1.f };
	float box_invisible[4] = { 1.f, 0.f, 0.f, 1.f };

	float box_filled_visible[4] = { 0.f, 1.f, 0.f, 0.2f };
	float box_filled_invisible[4] = { 1.f, 0.f, 0.f, 0.2f };

	float skeleton_visible[4] = { 0.f, 1.f, 0.f, 1.f };
	float skeleton_invisible[4] = { 1.f, 0.f, 0.f, 1.f };

	float username_visible[4] = { 0.f, 1.f, 0.f, 1.f };
	float username_invisible[4] = { 1.f, 0.f, 0.f, 1.f };



}





namespace Visuals {


	inline bool RGB = 0;

	inline bool enable_esp = 1;
	inline bool weapon_rarity = 0;
	// BOXS
	inline bool Box_ESP = 0;
	inline bool Cornered_ESP = 0;
	inline bool Filled_box = 0;
	inline bool colorcornered = 0;
	inline bool Rounded_ESP = 0;


	inline bool skeleton = 0;
	inline bool snapline = 0;
	inline bool username = 0;
	inline bool distance = 0;
	inline bool weapon = 0;
	inline bool Kill = 0;
	inline bool outline = 0;

	int render_distance = 2400;

	float head_size = 10.0f;

	inline int skeleton_thick = 1;

	static float color_Visible[3] = { 255.0f, 0.0f, 255.0f };
	static float color_invisible[3] = { 173 / 255.0f, 17 / 0.0f, 17 / 0.0f };
	static float color[3] = { 1.00f, 1.00f, 1.00f };




}


namespace RGB
{
	float rainbowSpeed = 0.001f; // Default rainbow speed
	static float hue = 0.0f;
	const ImColor rainbowColor = ImVec4(ImColor::HSV(hue, 1.0f, 1.0f));

}




namespace Misc
{
	inline bool RapidFire = 0;
	inline bool  AimWhileJumping = 0;
	inline bool Speedhack = 0;
	inline bool enable_menu = 0;
	inline bool TeamID = 1;
	inline bool DeveloperMode = 1;
	inline bool fps = 1;
	inline bool Watermark = 1;
	inline bool Crosshair = 0;
	inline bool playercount = 0;
	inline bool PlayerFly = 0;
	inline bool magicbullet = 0;
	inline bool FOVChanger = 0;
	inline float DefaultFOV = 120;
	inline bool Radar = 0;
	inline bool ClientSpinbot = 0;
	inline bool  WhileRotating;
	inline float radar_pos_x = 20.f;
	inline float radar_pos_y = 50.f;
	inline float radar_size = 200.f;
	inline float radar_range = 60.f;




	//inline int skeleton_thick = 2;
	inline int g_box_thick = 2;
	inline int line_thick = 2;



	static float SkeletonVisible[4] = { 1.f, 1.f, 1.f, 1.0f };
	static float SkeletonNotVisible[4] = { 1.f, 1.f, 1.f, 1.0f };





	inline bool g_weapon_cfg = 0; // 1 bbzn kodel

	static float g_color_Visible[3] = { 87 / 255.0f, 173 / 255.0f, 17 / 255.0f };
	static float g_color_invisible[3] = { 173 / 255.0f, 17 / 255.0f, 17 / 255.0f };
	static float g_color[3] = { 1.00f, 1.00f, 1.00f };

	static int g_color_fov[3] = { 1.00f, 1.00f, 1.00f };




}









namespace rifle
{

	inline bool aimbot = 1;
	inline bool ignore_downed = 1;
	inline bool ignore_bots = 0;
	inline bool visible_check = 1;
	inline bool target_line = 0;
	inline bool TargetText = 0;
	inline float aim_fov = 15;
	inline int smooth = 1;
	inline int hitbox = 0;
	inline int aimkey;
}

namespace shotgun
{

	inline bool aimbot = 1;
	inline bool ignore_downed = 1;
	inline bool ignore_bots = 0;
	inline bool visible_check = 1;
	inline bool target_line = 0;
	inline bool TargetText = 0;
	inline float aim_fov = 15;
	inline int smooth = 1;
	inline int hitbox = 0;
	inline int aimkey;

}

namespace smg
{
	inline bool aimbot = 1;
	inline bool ignore_downed = 1;
	inline bool ignore_bots = 0;
	inline bool visible_check = 1;
	inline bool target_line = 0;
	inline bool TargetText = 0;
	inline 	float aim_fov = 15;
	inline 	int smooth = 1;
	inline int hitbox = 0;
	inline int aimkey;

}

namespace sniper
{
	inline bool aimbot = 1;
	inline bool Prediction = 0;
	inline bool ignore_downed = 1;
	inline bool ignore_bots = 0;
	inline bool visible_check = 1;
	inline bool target_line = 0;
	inline bool TargetText = 0;
	inline	float aim_fov = 300;
	static int smooth = 1;
	inline int hitbox = 0;
	inline int aimkey;
}

