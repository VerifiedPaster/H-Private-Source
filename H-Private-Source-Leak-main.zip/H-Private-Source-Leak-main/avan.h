﻿#include <Windows.h>
#include <winternl.h>
#include <intrin.h>
#include <winnt.h>
#include "pebteb.h"
#include "SkCrypt.h"
#pragma comment(lib, "ntdll.lib")



#define DBG_CONVENTION __forceinline __fastcall



namespace NTDEFINES {
    typedef enum _THREAD_INFORMATION_CLASS {
        ThreadBasicInformation,
        ThreadTimes,
        ThreadPriority,
        ThreadBasePriority,
        ThreadAffinityMask,
        ThreadImpersonationToken,
        ThreadDescriptorTableEntry,
        ThreadEnableAlignmentFaultFixup,
        ThreadEventPair,
        ThreadQuerySetWin32StartAddress,
        ThreadZeroTlsCell,
        ThreadPerformanceCount,
        ThreadAmILastThread,
        ThreadIdealProcessor,
        ThreadPriorityBoost,
        ThreadSetTlsArrayAddress,
        ThreadIsIoPending,
        ThreadHideFromDebugger
    } THREAD_INFORMATION_CLASS, * PTHREAD_INFORMATION_CLASS;

    typedef enum _PROCESS_INFORMATION_CLASS {
        ProcessBasicInformation,
        ProcessQuotaLimits,
        ProcessIoCounters,
        ProcessVmCounters,
        ProcessTimes,
        ProcessBasePriority,
        ProcessRaisePriority,
        ProcessDebugPort,
        ProcessExceptionPort,
        ProcessAccessToken,
        ProcessLdtInformation,
        ProcessLdtSize,
        ProcessDefaultHardErrorMode,
        ProcessIoPortHandlers,
        ProcessPooledUsageAndLimits,
        ProcessWorkingSetWatch,
        ProcessUserModeIOPL,
        ProcessEnableAlignmentFaultFixup,
        ProcessPriorityClass,
        ProcessWx86Information,
        ProcessHandleCount,
        ProcessAffinityMask,
        ProcessPriorityBoost,
        ProcessDeviceMap,
        ProcessSessionInformation,
        ProcessForegroundInformation,
        ProcessWow64Information,
        ProcessImageFileName,
        ProcessLUIDDeviceMapsEnabled,
        ProcessBreakOnTermination,
        ProcessDebugObjectHandle,
        ProcessDebugFlags,
        ProcessHandleTracing,
        ProcessIoPriority,
        ProcessExecuteFlags,
        ProcessTlsInformation,
        ProcessCookie,
        ProcessImageInformation,
        ProcessCycleTime,
        ProcessPagePriority,
        ProcessInstrumentationCallback,
        ProcessThreadStackAllocation,
        ProcessWorkingSetWatchEx,
        ProcessImageFileNameWin32,
        ProcessImageFileMapping,
        ProcessAffinityUpdateMode,
        ProcessMemoryAllocationMode,
        ProcessGroupInformation,
        ProcessTokenVirtualizationEnabled,
        ProcessOwnerInformation,
        ProcessWindowInformation,
        ProcessHandleInformation,
        ProcessMitigationPolicy,
        ProcessDynamicFunctionTableInformation,
        ProcessHandleCheckingMode,
        ProcessKeepAliveCount,
        ProcessRevokeFileHandles,
        ProcessWorkingSetControl,
        ProcessHandleTable,
        ProcessCheckStackExtentsMode,
        ProcessCommandLineInformation,
        ProcessProtectionInformation,
        MaxProcessInfoClass
    } PROCESS_INFORMATION_CLASS, * PPROCESS_INFORMATION_CLASS;

    typedef enum _SYSTEM_INFORMATION_CLASS {
        SystemBasicInformation,
        SystemProcessorInformation,
        SystemPerformanceInformation,
        SystemTimeOfDayInformation,
        SystemPathInformation,
        SystemProcessInformation,
        SystemCallCountInformation,
        SystemDeviceInformation,
        SystemProcessorPerformanceInformation,
        SystemFlagsInformation,
        SystemCallTimeInformation,
        SystemModuleInformation,
        SystemLocksInformation,
        SystemStackTraceInformation,
        SystemPagedPoolInformation,
        SystemNonPagedPoolInformation,
        SystemHandleInformation,
        SystemObjectInformation,
        SystemPageFileInformation,
        SystemVdmInstemulInformation,
        SystemVdmBopInformation,
        SystemFileCacheInformation,
        SystemPoolTagInformation,
        SystemInterruptInformation,
        SystemDpcBehaviorInformation,
        SystemFullMemoryInformation,
        SystemLoadGdiDriverInformation,
        SystemUnloadGdiDriverInformation,
        SystemTimeAdjustmentInformation,
        SystemSummaryMemoryInformation,
        SystemMirrorMemoryInformation,
        SystemPerformanceTraceInformation,
        SystemObsolete0,
        SystemExceptionInformation,
        SystemCrashDumpStateInformation,
        SystemKernelDebuggerInformation
    } SYSTEM_INFORMATION_CLASS, * PSYSTEM_INFORMATION_CLASS;
}


typedef PVOID(WINAPI* _GetProcAddress)(HMODULE hModule, LPCSTR ProcName);

class hModules final {
private:
    static BOOL Initialized;
    static HMODULE _hNtdll;
    static HMODULE _hKernelBase;
    static HMODULE _hKernel32;
    static HMODULE _hProcess;
    static _GetProcAddress _XoredQueryAddress;
public:
    static HMODULE _hCurrent; // Current module
    static inline HMODULE hNtdll();
    static inline HMODULE hKernelBase();
    static inline HMODULE hKernel32();
    static inline HMODULE hProcess();
    static inline HMODULE hCurrent();
    static inline PVOID WINAPI QueryAddress(HMODULE hModule, LPCSTR ProcName);
};



HMODULE hModules::_hKernel32 = nullptr;
_GetProcAddress hModules::_XoredQueryAddress = nullptr;
HMODULE hModules::_hNtdll = nullptr;

#define GET_HMODULE(VarName, LibName) VarName ? VarName : VarName = GetModuleHandle(LibName)

inline HMODULE hModules::hNtdll() {
    return GET_HMODULE(_hNtdll, "ntdll.dll");
}

inline HMODULE hModules::hKernelBase() {
    return GET_HMODULE(_hKernelBase, "kernelbase.dll");
}

inline HMODULE hModules::hKernel32() {
    return GET_HMODULE(_hKernel32, "kernel32.dll");
}

inline HMODULE hModules::hProcess() {
    return GET_HMODULE(_hProcess, NULL);
}

inline HMODULE hModules::hCurrent() {
    return _hCurrent;
}

inline PVOID WINAPI hModules::QueryAddress(HMODULE hModule, LPCSTR ProcName) {
    return GetProcAddress(hModule, ProcName);
    const SIZE_T Key = (SIZE_T)0xF3C2A713B4340C2A;
    if (!_XoredQueryAddress)
        _XoredQueryAddress = (_GetProcAddress)((SIZE_T)GetProcAddress(hKernel32(), E("GetProcAddress")) ^ Key);
    return ((_GetProcAddress)((SIZE_T)_XoredQueryAddress ^ Key))(hModule, ProcName);
}

typedef struct _SYSTEM_KERNEL_DEBUGGER_INFORMATION {
    BOOLEAN DebuggerEnabled;
    BOOLEAN DebuggerNotPresent;
} SYSTEM_KERNEL_DEBUGGER_INFORMATION, * PSYSTEM_KERNEL_DEBUGGER_INFORMATION;


VOID DBG_CONVENTION DetachFromDebugger() {
    NtSetInformationThread(GetCurrentThread(), static_cast<THREADINFOCLASS>(NTDEFINES::ThreadHideFromDebugger), NULL, 0);
}

BOOL DBG_CONVENTION CheckDebugPortPresent() {
    HANDLE DebugPort;
    NtQueryInformationProcess(GetCurrentProcess(), (PROCESSINFOCLASS)NTDEFINES::ProcessDebugPort, &DebugPort, sizeof(DebugPort), NULL);
    return DebugPort != NULL;
}

BOOL DBG_CONVENTION CheckDebugFlagsPresent() {
    BOOL NoDebugInherit = FALSE;
    NtQueryInformationProcess(GetCurrentProcess(), (PROCESSINFOCLASS)NTDEFINES::ProcessDebugFlags, &NoDebugInherit, sizeof(NoDebugInherit), NULL);
    return !NoDebugInherit;
}

BOOL DBG_CONVENTION CheckDebugObjectPresent() {
    HANDLE DebugObjectHandle;
    NtQueryInformationProcess(GetCurrentProcess(), (PROCESSINFOCLASS)NTDEFINES::ProcessDebugObjectHandle, &DebugObjectHandle, sizeof(DebugObjectHandle), NULL);
    return DebugObjectHandle != NULL;
}

BOOL DBG_CONVENTION CheckNtClose() {
    __try {
        NtClose((HANDLE)0x1EE7C0DE);
        return FALSE;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return TRUE;
    }
}


BOOL DBG_CONVENTION CheckNtGlobalFlag() {
#define FLG_HEAP_ENABLE_TAIL_CHECK		(0x10)
#define FLG_HEAP_ENABLE_FREE_CHECK		(0x20)
#define FLG_HEAP_VALIDATE_PARAMETERS	(0x40)
#define DBG_SUMMARY_FLAG	(FLG_HEAP_ENABLE_TAIL_CHECK | FLG_HEAP_ENABLE_FREE_CHECK | FLG_HEAP_VALIDATE_PARAMETERS)

#ifdef _AMD64_
#define NT_GLOBAL_FLAG_OFFSET 0x68
#else
#define NT_GLOBAL_FLAG_OFFSET 0xBC
#endif

    DWORD NtGlobalFlag = *(PDWORD)((PBYTE)GetPEB() + NT_GLOBAL_FLAG_OFFSET);
    return (NtGlobalFlag & DBG_SUMMARY_FLAG) != 0;
}

BOOL DBG_CONVENTION CheckRDP() {
    BOOL RemoteDebuggerPresent;
    CheckRemoteDebuggerPresent(GetCurrentProcess(), &RemoteDebuggerPresent);
    return RemoteDebuggerPresent;
}

BOOL DBG_CONVENTION CheckIDP() {
    return IsDebuggerPresent();
}

BOOL DBG_CONVENTION CheckPebIDP() {
    return GetPEB()->BeingDebugged;
}

VOID DestroyDbgUiRemoteBreakin() {
    PVOID DbgUiRemoteBreakin = hModules::QueryAddress(hModules::hNtdll(), E("DbgUiRemoteBreakin"));
    if (DbgUiRemoteBreakin) {
        DWORD OldProtect;
        VirtualProtect(DbgUiRemoteBreakin, sizeof(DWORD), PAGE_EXECUTE_READWRITE, &OldProtect);
        *(PDWORD)DbgUiRemoteBreakin = 0x1EE7C0DE; // Ломаем функцию
        VirtualProtect(DbgUiRemoteBreakin, sizeof(DWORD), OldProtect, &OldProtect);
    }
}
extern "C"
__declspec(dllimport)
NTSTATUS __stdcall
NtRaiseException(
    PEXCEPTION_RECORD ExceptionRecord,
    PCONTEXT ThreadContext,
    BOOLEAN HandleException
);

extern "C"
__declspec(dllimport)
NTSTATUS __stdcall
NtSetDebugFilterState(
    ULONG ComponentId,
    ULONG Level,
    BOOLEAN State
);

BOOL DBG_CONVENTION CheckNtRaiseException() {
    __try {
        CONTEXT Context;
        RtlCaptureContext(&Context);

        EXCEPTION_RECORD ExceptionRecord;
        ExceptionRecord.ExceptionCode = EXCEPTION_INVALID_HANDLE;
        ExceptionRecord.ExceptionFlags = 0; // EXCEPTION_CONTINUABLE
        ExceptionRecord.ExceptionAddress = 0x00000000;
        ExceptionRecord.ExceptionRecord = &ExceptionRecord;
        ExceptionRecord.NumberParameters = 0;

        NtRaiseException(&ExceptionRecord, &Context, TRUE); // Поднимаем исключение
        return TRUE; // Обработано, есть отладчик
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return FALSE; // Не обработано, отладчика нет
    }
}

BOOL DBG_CONVENTION CheckDbgFilterState() {
    // Сбрасываем фильтрацию отладочных сообщений:
    return NtSetDebugFilterState(0, 0, TRUE) == ERROR_SUCCESS;
}

