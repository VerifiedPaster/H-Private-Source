﻿#include <Windows.h>
#include <iostream>
#include "menu.h"
#include "xorst.h"
#include "protect/antiDbg.h"
#include <tchar.h>
#include <urlmon.h>

#pragma comment(lib,"urlmon.lib")
#pragma comment(lib,"wininet.lib")
#pragma comment(lib, "winmm.lib")




HWND windows = NULL;

// Keyauth info
using namespace KeyAuth;




std::string name = skCrypt("FnPrivate").decrypt();
std::string ownerid = skCrypt("g7Img1SY5D").decrypt();
std::string secret = skCrypt("9d8789e8b6181a49b30d6dd66ed65d6c777956478c53f0a2359f01fded350f3b").decrypt();
std::string version = skCrypt("1.0").decrypt();
std::string url = skCrypt("https://keyauth.win/api/1.2/").decrypt(); // change if you're self-hosting

api KeyAuthApp(name, ownerid, secret, version, url);



//Keyauth Code
void keyauth()
{
	if (!KeyAuthApp.data.success)
	{
		std::cout << E("\n Status: ").decrypt() << KeyAuthApp.data.message;
		Sleep(1500);
		exit(1);
	}
	std::string key;
	system(E("cls").decrypt());
	std::cout << E("\n Enter license: ").decrypt();
	std::cin >> key;
	KeyAuthApp.license(key);
	if (KeyAuthApp.data.username == "gelion") {
		BlackList();
	}

	if (!KeyAuthApp.data.success)
	{
		system(E("cls").decrypt());
		std::cout << E("\n Status: ").decrypt() << KeyAuthApp.data.message;
		Sleep(1500);
		exit(1);
	}
}




// Loading Driver
bool SearchFileRecursive(const std::string& directory, const char* filename) {
	std::string searchPath = directory + "\\*.*";
	WIN32_FIND_DATA findFileData;
	HANDLE hFind = FindFirstFile(searchPath.c_str(), &findFileData);

	if (hFind != INVALID_HANDLE_VALUE) {
		do {
			if (findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
				if (strcmp(findFileData.cFileName, ".") != 0 && strcmp(findFileData.cFileName, "..") != 0) {
					std::string subdirectory = directory + "\\" + findFileData.cFileName;
					if (SearchFileRecursive(subdirectory, filename)) {
						return true;
					}
				}
			}
			else {
				if (strcmp(findFileData.cFileName, filename) == 0) {
					std::cout << "File found: " << directory + "\\" + filename << std::endl;
					return true;
				}
			}
		} while (FindNextFile(hFind, &findFileData) != 0);
		FindClose(hFind);
	}
	return false;
}




auto main() -> int {

	name.clear(); ownerid.clear(); secret.clear(); version.clear(); url.clear();

	//std::thread security(security_loop);

	mouse_interface();
	LI_FN(SetConsoleTitleA)(skCrypt(("CapWare")));


	input->initialize();


	screen_width = GetSystemMetrics(SM_CXSCREEN), screen_height = GetSystemMetrics(SM_CYSCREEN);

	/*KeyAuthApp.init();
	keyauth();
	KeyAuthApp.log("Monkey Logged In");*/



maain:
	system(E("cls"));
	system(E("color b"));

	std::cout << E("\n Do You Want To Load The Driver (y/n) ? : ").decrypt();
	char drv;
	std::cin >> drv;

	if (drv == 'y' || drv == 'Y')
	{

		ShowWindow_Spoofed(GetConsoleWindow(), SW_HIDE);
		if (KeyAuthApp.data.success)
		{
			//Load();
			//Load1();
		}
		else
		{
			std::cout << E("\n Kys").decrypt();
		}
		system(E("cls").decrypt());
		LI_FN(Sleep)(1000);
		ShowWindow_Spoofed(GetConsoleWindow(), SW_SHOW);
		system(E("cls"));
		std::cout << E("\n Watting For Fortnite...").decrypt();
		H::find_driver();



		while (windows == NULL)
		{

			XorS(wind, "Fortnite  ");
			windows = FindWindowA_Spoofed(0, wind.decrypt());
		}
		//driver
		H::find_process(E("FortniteClient-Win64-Shipping.exe"));
		base_address = H::get_base_address();
		
		for (int i = 0; i < 25; i++)
		{
			if ((read<__int32>(base_address + (i * 0x1000) + 0x250)) == 0x260E020B)
			{
				g_ptr->va_text = base_address + ((i + 1) * 0x1000);
			}
		}

		// Loaded	
		system(E("cls"));
		std::cout << E(" Base address -> ") << base_address << std::endl;

		//loop
		std::thread([&]() { for (;; ) { g_main->cache_entities(); } }).detach();

		//Menu
		render->hijack();
		render->imgui();
		render->render();
	}
	if (drv == 'n' || drv == 'N')
	{
		system(E("cls"));
		std::cout << E("\n Watting For Fortnite...");
		H::find_driver();

		
		while (windows == NULL)
		{

			XorS(wind, "Fortnite  ");
			windows = FindWindowA_Spoofed(0, wind.decrypt());
		}
		//driver
		H::find_process(E("FortniteClient-Win64-Shipping.exe"));
		base_address = H::get_base_address();
		for (int i = 0; i < 25; i++)
		{
			if ((read<__int32>(base_address + (i * 0x1000) + 0x250)) == 0x260E020B)
			{
				g_ptr->va_text = base_address + ((i + 1) * 0x1000);
			}
		}

		// Loaded	
		//system(E("cls"));
		std::cout << E(" Base address -> ") << base_address << std::endl;
		//loop
		std::thread([&]() { for (;; ) { g_main->cache_entities(); } }).detach();

		//Menu
		render->hijack();
		render->imgui();
		render->render();
	}
	else {
		goto maain;
	}


}

