#pragma once
#include <cstdint>
#include <basetsd.h>
#include <WTypesbase.h>
#include <TlHelp32.h>
#include "../spoofer.h"

uint64_t base_address;
//VMDriver
#define FindBaseAddress CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1588, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define ReadProcessMemory CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1589, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define WriteProcessMemory CTL_CODE(FILE_DEVICE_UNKNOWN, 0x1590, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)


enum REQUEST_TYPE : int	
{
	NONE,
	BASE,
	WRITE,
	READ
};
typedef struct _DRIVER_REQUEST
{
	REQUEST_TYPE type;
	HANDLE pid;
	PVOID address;
	PVOID buffer;
	SIZE_T size;
	PVOID base;
} DRIVER_REQUEST, * PDRIVER_REQUEST;

namespace H {
	HANDLE driver_handle;
	INT32 process_id;

	bool find_driver()
	{
		SPOOF_FUNC;
		//VMDriver WNBIOS SE64
		driver_handle = CreateFileA(E("\\\\.\\VMDriver").decrypt(), GENERIC_READ, 0, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);

		if (!driver_handle || (driver_handle == INVALID_HANDLE_VALUE))
			return false;

		return true;
	}
	
	void readm(PVOID address, PVOID buffer, DWORD size)
    {
		SPOOF_FUNC;

		DRIVER_REQUEST out{};
		out.type = READ;
		out.pid = (HANDLE)process_id;
		out.address = address;
		out.buffer = buffer;
		out.size = size;
		DeviceIoControl(driver_handle, ReadProcessMemory, &out, sizeof(out), &out, sizeof(out), nullptr, nullptr);
	}
	inline bool read1(const std::uintptr_t address, void* buffer, const std::size_t size)
	{
		SPOOF_FUNC;

		if (buffer == nullptr || size == 0) {
			return false;
		}
		readm(reinterpret_cast<PVOID>(address), buffer, static_cast<DWORD>(size));
	}

	void writem(PVOID address, PVOID buffer, DWORD size)
	{
		SPOOF_FUNC;

		DRIVER_REQUEST out{};
		out.type = WRITE;
		out.pid = (HANDLE)process_id;
		out.address = address;
		out.buffer = buffer;
		out.size = size;
		DeviceIoControl(driver_handle, WriteProcessMemory, &out, sizeof(out), &out, sizeof(out), nullptr, nullptr);
	}

	uintptr_t get_base_address()
	{
		SPOOF_FUNC;

		DRIVER_REQUEST io_info{};
		io_info.type = BASE;
		io_info.pid = (HANDLE)process_id;

		DeviceIoControl(driver_handle, FindBaseAddress, &io_info, sizeof(io_info), &io_info, sizeof(io_info), nullptr, nullptr);
		return (uintptr_t)io_info.base;
	}

	INT32 find_process(LPCTSTR process_name)
	{
		SPOOF_FUNC;

		PROCESSENTRY32 pt;
		HANDLE hsnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
		pt.dwSize = sizeof(PROCESSENTRY32);
		if (Process32First(hsnap, &pt)) {
			do {
				if (!lstrcmpi(pt.szExeFile, process_name)) {
					CloseHandle(hsnap);
					process_id = pt.th32ProcessID;
					return pt.th32ProcessID;
				}
			} while (Process32Next(hsnap, &pt));
		}
		CloseHandle(hsnap);

		return { NULL };
	}
}

bool is_valid(const uint64_t adress)
{
	SPOOF_FUNC;

	if (adress <= 0x400000 || adress == 0xCCCCCCCCCCCCCCCC || reinterpret_cast<void*>(adress) == nullptr || adress >
		0x7FFFFFFFFFFFFFFF) {
		return false;
	}
	return true;
}

template<typename T> T read(uintptr_t address)
{
	SPOOF_FUNC;

	if (is_valid)
	{
		T buffer{};
		H::readm((PVOID)address, &buffer, sizeof(T));
		return buffer;
	}

}
template <typename T>
T write(uint64_t address, T buffer) {

	SPOOF_FUNC;

	if (is_valid)
	{
		H::writem((PVOID)address, &buffer, sizeof(T));
		return buffer;
	}

}
inline bool read1(const std::uintptr_t address, void* buffer, const std::size_t size)
{
	SPOOF_FUNC;

	if (!is_valid(address)) return false;
	if (buffer == nullptr || size == 0) {
		return false;
	}
	H::readm(reinterpret_cast<PVOID>(address), buffer, static_cast<DWORD>(size));
}

template<typename T>
void ReadArray(uint64_t address, T* array, size_t len)
{
	SPOOF_FUNC;

	if (!is_valid(address)) return;
	H::readm(reinterpret_cast<PVOID>(address), reinterpret_cast<PVOID>(array), sizeof(T) * len);
}

template<typename T>
bool read_array(uintptr_t address, T out[], size_t len)
{
	SPOOF_FUNC;

	if (!is_valid(address)) return false;
	for (size_t i = 0; i < len; ++i)
	{
		out[i] = read<T>(address + i * sizeof(T));
	}
	return true; // you can add additional checks to verify successful reads
}