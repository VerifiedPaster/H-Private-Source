
#include <iostream>
#include "adbgmodules.h"
#include "SkCrypt.h"
#include "lazy.h"



#define SHOW_DEBUG_MESSAGES

bool debug = false;

void adbg_CheckRemoteDebuggerPresent(void)
{
    HANDLE hProcess = INVALID_HANDLE_VALUE;
    BOOL found = FALSE;

    hProcess = GetCurrentProcess();
    CheckRemoteDebuggerPresent(hProcess, &found);

    if (found)
    {
        debug = true;
        LI_FN(exit)(0);
        LI_FN(ExitProcess)(0);
        LI_FN(abort)();
        *((unsigned int*)0) = 0xDEAD;
    }
}

void adbg_ProcessFileName(void)
{
    // detect debugger by process file (for example: ollydbg.exe)
    const wchar_t* debuggersFilename[6] = {
        E(L"cheatengine-x86_64.exe"),
        E(L"ollydbg.exe"),
        E(L"ida.exe"),
        E(L"ida64.exe"),
        E(L"radare2.exe"),
        E(L"x64dbg.exe")
    };

    wchar_t* processName;
    PROCESSENTRY32W processInformation{ sizeof(PROCESSENTRY32W) };
    HANDLE processList;

    processList = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
    processInformation = { sizeof(PROCESSENTRY32W) };
    if ((Process32FirstW(processList, &processInformation)))
        do
        {
            for (const wchar_t* debugger : debuggersFilename)
            {
                processName = processInformation.szExeFile;
                if (_wcsicmp(debugger, processName) == 0) {
                    debug = true;
                    LI_FN(exit)(0);
                    LI_FN(ExitProcess)(0);
                    LI_FN(abort)();
                    *((unsigned int*)0) = 0xDEAD;
                }
            }
        } while (Process32NextW(processList, &processInformation));
        CloseHandle(processList);
}



void adbg_IsDebuggerPresent(void)
{
    BOOL found = FALSE;
    found = IsDebuggerPresent();

    if (found)
    {
        debug = true;
        LI_FN(exit)(0);
        LI_FN(ExitProcess)(0);
        LI_FN(abort)();
        *((unsigned int*)0) = 0xDEAD;
    }
}



void adbg_NtQueryInformationProcess(void)
{
    HANDLE hProcess = INVALID_HANDLE_VALUE;
    PROCESS_BASIC_INFORMATION pProcBasicInfo = { 0 };
    ULONG returnLength = 0;

    // Get a handle to ntdll.dll so we can import NtQueryInformationProcess
    HMODULE hNtdll = LoadLibraryW(E(L"ntdll.dll"));
    if (hNtdll == INVALID_HANDLE_VALUE || hNtdll == NULL)
    {
        return;
    }

    // Dynamically acquire the addres of NtQueryInformationProcess
    _NtQueryInformationProcess  NtQueryInformationProcess = NULL;
    NtQueryInformationProcess = (_NtQueryInformationProcess)GetProcAddress(hNtdll, E("NtQueryInformationProcess"));

    if (NtQueryInformationProcess == NULL)
    {
        return;
    }

    hProcess = GetCurrentProcess();


    NTSTATUS status = NtQueryInformationProcess(hProcess, ProcessBasicInformation, &pProcBasicInfo, sizeof(pProcBasicInfo), NULL);
    if (NT_SUCCESS(status)) {
        PPEB pPeb = pProcBasicInfo.PebBaseAddress;
        if (pPeb)
        {
            if (pPeb->BeingDebugged)
            {

                debug = true;
                LI_FN(exit)(0);
                LI_FN(ExitProcess)(0);
                LI_FN(abort)();
                *((unsigned int*)0) = 0xDEAD;
            }
        }
    }
}


void adbg_NtSetInformationThread(void)
{
    THREAD_INFORMATION_CLASS ThreadHideFromDebugger = (THREAD_INFORMATION_CLASS)0x11;

    // Get a handle to ntdll.dll so we can import NtSetInformationThread
    HMODULE hNtdll = LoadLibraryW(E(L"ntdll.dll"));
    if (hNtdll == INVALID_HANDLE_VALUE || hNtdll == NULL)
    {
        return;
    }

    // Dynamically acquire the addres of NtSetInformationThread and NtQueryInformationThread
    _NtSetInformationThread NtSetInformationThread = NULL;
    NtSetInformationThread = (_NtSetInformationThread)GetProcAddress(hNtdll, E("NtSetInformationThread"));

    if (NtSetInformationThread == NULL)
    {
        return;
    }

    // There is nothing to check here after this call.
    NtSetInformationThread(GetCurrentThread(), ThreadHideFromDebugger, 0, 0);
}


void adbg_DebugActiveProcess(const char* cpid)
{
    BOOL found = FALSE;
    STARTUPINFOA si = { 0 };
    PROCESS_INFORMATION pi = { 0 };
    si.cb = sizeof(si);
    TCHAR szPath[MAX_PATH];
    DWORD exitCode = 0;

    CreateMutex(NULL, FALSE, E("antidbg"));
    if (GetLastError() != ERROR_SUCCESS)
    {
        // If we get here we are in the child process
        if (DebugActiveProcess((DWORD)atoi(cpid)))
        {
            // No debugger found.
            return;
        }
        else
        {
            debug = true;
            LI_FN(exit)(0);
            LI_FN(ExitProcess)(0);
            LI_FN(abort)();
            *((unsigned int*)0) = 0xDEAD;
        }
    }

    // parent process
    DWORD pid = GetCurrentProcessId();
    GetModuleFileName(NULL, szPath, MAX_PATH);

    char cmdline[MAX_PATH + 1 + sizeof(int)];
    //snprintf(cmdline, sizeof(cmdline), E("%ws %d"), szPath, pid);

    // Start the child process. 
    BOOL success = CreateProcessA(
        NULL,		// path (NULL means use cmdline instead)
        cmdline,	// Command line
        NULL,		// Process handle not inheritable
        NULL,		// Thread handle not inheritable
        FALSE,		// Set handle inheritance to FALSE
        0,			// No creation flags
        NULL,		// Use parent's environment block
        NULL,		// Use parent's starting directory 
        &si,		// Pointer to STARTUPINFO structure
        &pi);		// Pointer to PROCESS_INFORMATION structure

    // Wait until child process exits and get the code
    WaitForSingleObject(pi.hProcess, INFINITE);

    // Check for our unique exit code
    GetExitCodeProcess(pi.hProcess, &exitCode);
    if (exitCode == 555)
    {
        found = TRUE;
    }

    // Close process and thread handles. 
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    if (found)
    {
        debug = true;
        LI_FN(exit)(0);
        LI_FN(ExitProcess)(0);
        LI_FN(abort)();
        *((unsigned int*)0) = 0xDEAD;
    }
}


void adbg_HardwareDebugRegisters(void)
{
    BOOL found = FALSE;
    CONTEXT ctx = { 0 };
    HANDLE hThread = GetCurrentThread();

    ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
    if (GetThreadContext(hThread, &ctx))
    {
        if ((ctx.Dr0 != 0x00) || (ctx.Dr1 != 0x00) || (ctx.Dr2 != 0x00) || (ctx.Dr3 != 0x00) || (ctx.Dr6 != 0x00) || (ctx.Dr7 != 0x00))
        {
            found = TRUE;
        }
    }

    if (found)
    {
        debug = true;
        LI_FN(exit)(0);
        LI_FN(ExitProcess)(0);
        LI_FN(abort)();
        *((unsigned int*)0) = 0xDEAD;
    }
}


void adbg_MovSS(void)
{
    BOOL found = FALSE;

#ifdef _WIN64
    // This method does not work on x64
#else
    _asm
    {
        push ss;
        pop ss;
        pushfd;
        test byte ptr[esp + 1], 1;
        jne fnd;
        jmp end;
    fnd:
        mov found, 1;
    end:
        nop;
    }
#endif

    if (found)
    {
        debug = true;
        LI_FN(exit)(0);
        LI_FN(ExitProcess)(0);
        LI_FN(abort)();
        *((unsigned int*)0) = 0xDEAD;
    }
}




void adbg_CloseHandleException(void)
{
    HANDLE hInvalid = (HANDLE)0xBEEF; // an invalid handle
    DWORD found = FALSE;

    __try
    {
        CloseHandle(hInvalid);
    }
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        found = TRUE;
    }

    if (found)
    {
        debug = true;
        LI_FN(exit)(0);
        LI_FN(ExitProcess)(0);
        LI_FN(abort)();
        *((unsigned int*)0) = 0xDEAD;
    }
}







void adbg_PrefixHop(void)
{
    BOOL found = TRUE;

    __try
    {
#ifdef _WIN64
        // TODO: Not yet implemented in x64
        found = FALSE;
#else
        _asm
        {
            __emit 0xF3;	// 0xF3 0x64 is the prefix 'REP'
            __emit 0x64;
            __emit 0xCC;	// this gets skipped over if being debugged
        }
#endif
    }

    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        found = FALSE;
    }

    if (found)
    {
        debug = true;
        LI_FN(exit)(0);
        LI_FN(ExitProcess)(0);
        LI_FN(abort)();
        *((unsigned int*)0) = 0xDEAD;
    }
}


bool IsDebugger()
{
    debug = false;

    adbg_CheckRemoteDebuggerPresent();
    adbg_ProcessFileName();
    adbg_IsDebuggerPresent();
    adbg_NtQueryInformationProcess();
    adbg_NtSetInformationThread();
    adbg_HardwareDebugRegisters();
    adbg_MovSS();
    adbg_CloseHandleException();
    adbg_PrefixHop();

    return debug;

}