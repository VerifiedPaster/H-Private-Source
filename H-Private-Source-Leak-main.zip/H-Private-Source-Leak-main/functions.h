#include <string.h>
#include <list>
#include <string>
#include "ue.h"
#include "Driver/defs.h"


namespace uee
{





	class ue 
	{
	public:

		bool sides = true;
		


		void Anim_circle(float r, bool filled, bool rainbow, bool toMouse) {
			auto& io = ImGui::GetIO();

			ImVec2 center = toMouse ? ImVec2(io.MousePos.x, io.MousePos.y) : ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f);
			auto drawList = ImGui::GetBackgroundDrawList();

			for (int i = 0; i < sides; ++i) {
				auto pos = center;
				float angle = (i / static_cast<float>(sides)) * 2 * M_PI;
				auto lastPos = ImVec2(pos.x + cos(angle) * r, pos.y + sin(angle) * r);
				auto nextPos = ImVec2(pos.x + cos(angle + 2 * M_PI / sides) * r, pos.y + sin(angle + 2 * M_PI / sides) * r);

				ImU32 currentColor = rainbow ? ImGui::ColorConvertFloat4ToU32(ImColor::HSV((fmod(ImGui::GetTime(), 5.0f) / 5.0f - i / static_cast<float>(sides)) + 1.0f, 0.5f, 1.0f)) : IM_COL32(255, 255, 255, 255);

				ImU32 fillCol = filled ? ImGui::ColorConvertFloat4ToU32({ ImGui::ColorConvertU32ToFloat4(currentColor).x, ImGui::ColorConvertU32ToFloat4(currentColor).y, ImGui::ColorConvertU32ToFloat4(currentColor).z, 0.2f }) : 0; // 0.2f = fill opacity

				if (filled) {
					ImVec2 triangle[3] = { lastPos, nextPos, center };
					drawList->AddConvexPolyFilled(triangle, 3, fillCol); // fill
				}
				
					drawList->AddLine(lastPos, nextPos, IM_COL32(0, 0, 0, 255), 4.f); // outline 
					
					drawList->AddLine(lastPos, nextPos, currentColor, 2.f); // main 
				
			}

		}

		void OpenWebsite(const char* url) {

			ShellExecuteA(NULL, "open", url, NULL, NULL, SW_SHOWNORMAL);
		}

		// Platform
		__forceinline std::string platform(uint64_t PlayerState)
		{
			DWORD_PTR test_platform = read<DWORD_PTR>(PlayerState + 0x438);
			wchar_t platform[64];
			//read_array((uint64_t)test_platform, (uint8_t*)platform, sizeof(platform));
			std::wstring platform_wstr(platform);
			std::string platform_str(platform_wstr.begin(), platform_wstr.end());
			return platform_str;
		}

		// Player Name

		auto get_player_name( uintptr_t player_state ) -> std::string
		{

			int pNameLength;
			_WORD* pNameBufferPointer;
			int i;
			char v25;
			int v26;
			int v29;

			char16_t* pNameBuffer;

			uintptr_t pNameStructure = read < uintptr_t > ( player_state + 0xAB0); //pNameStructure
			if (is_valid(pNameStructure)) {
				pNameLength = read <int> ( pNameStructure + 0x10 );
				if ( pNameLength <= 0 )
					return "AI";

				pNameBuffer = new char16_t[pNameLength];
				uintptr_t pNameEncryptedBuffer = read <uintptr_t>( pNameStructure + 0x8 );
				if (is_valid(pNameEncryptedBuffer)) {
					//read_array (pNameEncryptedBuffer, pNameBuffer, pNameLength);

					v25 = pNameLength - 1;
					v26 = 0;
					pNameBufferPointer = (_WORD*)pNameBuffer;

					for (i = (v25) & 3;; *pNameBufferPointer++ += i & 7) {
						v29 = pNameLength - 1;
						if (!(_DWORD)pNameLength)
							v29 = 0;

						if (v26 >= v29)
							break;

						i += 3;
						++v26;
					}

					std::u16string temp_wstring(pNameBuffer);
					delete[] pNameBuffer;
					return std::string(temp_wstring.begin(), temp_wstring.end());
				}
			}
		}


		auto in_screen(fvector2d screen_location) -> bool {

			if (screen_location.x > 0 && screen_location.x < screen_width && screen_location.y > 0 && screen_location.y < screen_height) return true;
			else return false;

		}

		camera_position_s get_camera()
		{

			camera_position_s camera;

			auto location_pointer = read <uintptr_t>(g_ptr->uworld + 0x110); // -> 0x120
			auto rotation_pointer = read <uintptr_t>(g_ptr->uworld + 0x120);// - > 0x138

			struct FNRot
			{
				double a; //0x0000
				char pad_0008[24]; //0x0008
				double b; //0x0020
				char pad_0028[424]; //0x0028
				double c; //0x01D0
			} fnRot;

			fnRot.a = read <double>(rotation_pointer);
			fnRot.b = read <double>(rotation_pointer + 0x20);
			fnRot.c = read <double>(rotation_pointer + 0x1d0);

			camera.location = read <fvector>(location_pointer);
			camera.rotation.x = asin(fnRot.c) * (180.0 / M_PI);
			camera.rotation.y = ((atan2(fnRot.a * -1, fnRot.b) * (180.0 / M_PI)) * -1) * -1;
			camera.fov = read <float>(g_ptr->player_controller + 0x394) * 90.f;
			return camera;
		}

		inline fvector2d w2s(fvector WorldLocation)
		{
			camera_postion = get_camera();

			if (WorldLocation.x == 0)
				return fvector2d(0, 0);

			_MATRIX tempMatrix = Matrix(camera_postion.rotation);

			fvector vAxisX = fvector(tempMatrix.m[0][0], tempMatrix.m[0][1], tempMatrix.m[0][2]);
			fvector vAxisY = fvector(tempMatrix.m[1][0], tempMatrix.m[1][1], tempMatrix.m[1][2]);
			fvector vAxisZ = fvector(tempMatrix.m[2][0], tempMatrix.m[2][1], tempMatrix.m[2][2]);
			fvector vDelta = WorldLocation - camera_postion.location;
			fvector vTransformed = fvector(vDelta.dot(vAxisY), vDelta.dot(vAxisZ), vDelta.dot(vAxisX));
			if (vTransformed.z < 1.f)
				vTransformed.z = 1.f;
			return fvector2d((screen_width / 2.0f) + vTransformed.x * (((screen_width / 2.0f) / tanf(camera_postion.fov * (float)M_PI / 360.f))) / vTransformed.z, (screen_height / 2.0f) - vTransformed.y * (((screen_width / 2.0f) / tanf(camera_postion.fov * (float)M_PI / 360.f))) / vTransformed.z);
		}

		fvector Targer_Prediction(fvector Target, fvector Velocityy, float GetProjectileSpeed, float ProjectileGravity, float DistanceToTarget)
		{
			float horizontalTime = DistanceToTarget / GetProjectileSpeed;
			float verticalTime = DistanceToTarget / GetProjectileSpeed;

			Target.x += Velocityy.x * horizontalTime;
			Target.y += Velocityy.y * horizontalTime;
			Target.z += Velocityy.z * verticalTime +
				abs(-980.f * ProjectileGravity) * 0.5f *
				(verticalTime * verticalTime);

			return Target;
		}
		fvector H_TimeToTarget(fvector CalculatedPosition, fvector Velocity, float ProjectileSpeed, float ProjectileGravity, float Distance)
		{
			float TimeToTarget = Distance / ProjectileSpeed;

			CalculatedPosition.x += Velocity.x * (TimeToTarget) * 120;
			CalculatedPosition.y += Velocity.y * (TimeToTarget) * 120;
			CalculatedPosition.z += Velocity.z * (TimeToTarget) * 120;
			CalculatedPosition.z +=
				fabsf((-49000 / 50) * ProjectileGravity) *
				(TimeToTarget * TimeToTarget) / 2.0f;

			return CalculatedPosition;

		}



		 static auto get_bone_3d(uintptr_t skeletal_mesh, int bone_index) -> fvector {
			 uintptr_t bone_array = read<uintptr_t>(skeletal_mesh + offset::bone_array);
			 if (bone_array == NULL) bone_array = read<uintptr_t>(skeletal_mesh + offset::bone_array + 0x10);
			 FTransform bone = read<FTransform>(bone_array + (bone_index * 0x60));
			 FTransform component_to_world = read<FTransform>(skeletal_mesh + offset::component_to_world);
			 D3DMATRIX matrix = MatrixMultiplication(bone.ToMatrixWithScale(), component_to_world.ToMatrixWithScale());
			 return fvector(matrix._41, matrix._42, matrix._43);
		}

		static auto is_visible(uintptr_t skeletal_mesh) -> bool {

			auto last_submit = read <float>(skeletal_mesh + offset::LAST_SUMBIT_TIME);
			auto last_render = read <float>(skeletal_mesh + offset::LAST_SUMBIT_TIME_ON_SCREEN);
			return (bool)(last_render + 0.06f >= last_submit);

		}

		auto is_shootable(fvector lur, fvector bone) -> bool {
			SPOOF_FUNC

				if (lur.x >= bone.x - 20 && lur.x <= bone.x + 20 && lur.y >= bone.y - 20 && lur.y <= bone.y + 20 && lur.z >= bone.z - 30 && lur.z <= bone.z + 30) return true;
				else return false;

		}
		// radar

		void RadarRange(float* x, float* y, float range)
		{
			if (fabs((*x)) > range || fabs((*y)) > range)
			{
				if ((*y) > (*x))
				{
					if ((*y) > -(*x))
					{
						(*x) = range * (*x) / (*y);
						(*y) = range;
					}
					else
					{
						(*y) = -range * (*y) / (*x);
						(*x) = -range;
					}
				}
				else
				{
					if ((*y) > -(*x))
					{
						(*y) = range * (*y) / (*x);
						(*x) = range;
					}
					else
					{
						(*x) = -range * (*x) / (*y);
						(*y) = -range;
					}
				}

			}
		}
		void CalcRadarPoint(fvector vOrigin, int& screenx, int& screeny)
		{
			fvector vAngle = camera_postion.rotation;
			auto fYaw = vAngle.y * M_PI / 180.0f;
			float dx = vOrigin.x - camera_postion.location.x;
			float dy = vOrigin.y - camera_postion.location.y;

			//x' = x * cos(p) - y * sin(p)
			//y' = y * sin(p) - y * -cos(p)
			float fsin_yaw = sinf(fYaw);
			float fminus_cos_yaw = -cosf(fYaw);

			float x = dy * fminus_cos_yaw + dx * fsin_yaw;
			x = -x;
			float y = dx * fminus_cos_yaw - dy * fsin_yaw;

			float range = (float)Misc::radar_range * 1000.f;

			RadarRange(&x, &y, range);

			ImVec2 DrawPos = ImVec2(Misc::radar_pos_x, Misc::radar_pos_y);
			ImVec2 DrawSize = ImVec2(Misc::radar_size, Misc::radar_size);

			int rad_x = (int)DrawPos.x;
			int rad_y = (int)DrawPos.y;

			float r_siz_x = DrawSize.x;
			float r_siz_y = DrawSize.y;

			int x_max = (int)r_siz_x + rad_x - 5;
			int y_max = (int)r_siz_y + rad_y - 5;

			screenx = rad_x + ((int)r_siz_x / 2 + int(x / range * r_siz_x));
			screeny = rad_y + ((int)r_siz_y / 2 + int(y / range * r_siz_y));

			if (screenx > x_max)
				screenx = x_max;

			if (screenx < rad_x)
				screenx = rad_x;

			if (screeny > y_max)
				screeny = y_max;

			if (screeny < rad_y)
				screeny = rad_y;
		}
		void render_radar_main() {
			ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(Misc::radar_pos_x, Misc::radar_pos_y), ImVec2(Misc::radar_pos_x + Misc::radar_size, Misc::radar_pos_y + Misc::radar_size), ImGui::GetColorU32({ 0.13f, 0.13f, 0.13f, 0.f }), 0.f, 0);
			ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(Misc::radar_pos_x + (Misc::radar_size / 2), Misc::radar_pos_y + (Misc::radar_size / 2)), Misc::radar_size / 2, ImGui::GetColorU32({ 1.f, 1.f, 1.f, 1.f }), 64, 0.f);

			ImVec2 center = ImVec2(Misc::radar_pos_x + (Misc::radar_size / 2), Misc::radar_pos_y + (Misc::radar_size / 2));
			float orangeCircleRadius = 2.3f;
			ImGui::GetBackgroundDrawList()->AddCircleFilled(center, orangeCircleRadius, ImGui::GetColorU32({ 1.f, 1.f, 1.f, 1.f }), 12);
		}
		void add_to_radar(fvector WorldLocation, float fDistance, bool visible) {
			int ScreenX, ScreenY = 0;
			CalcRadarPoint(WorldLocation, ScreenX, ScreenY);

			if (!visible)
			{
				ImGui::GetBackgroundDrawList()->AddCircleFilled(ImVec2(ScreenX, ScreenY), 6.f, ImGui::GetColorU32({ 1.f, 0.f, 0.f, 1.f }), 12);
			}
			else
			{
				ImGui::GetBackgroundDrawList()->AddCircleFilled(ImVec2(ScreenX, ScreenY), 6.f, ImGui::GetColorU32({ 0.f, 1.f, 0.f, 1.f }), 12);
			}

			ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(ScreenX, ScreenY), 6.f, ImGui::GetColorU32({ 0.f, 0.f, 0.f, 1.f }), 12, 1.f);
		}
	};  static uee::ue* ue5 = new uee::ue();


}

int HeldWeaponType;

enum EFortWeaponType : int
{
	Rifle = 0,
	Shotgun = 1,
	Smg = 2,
	Sniper = 3
};

char* wchar_to_char(const wchar_t* pwchar)
{
	int currentCharIndex = 0;
	char currentChar = pwchar[currentCharIndex];

	while (currentChar != '\0')
	{
		currentCharIndex++;
		currentChar = pwchar[currentCharIndex];
	}

	const int charCount = currentCharIndex + 1;

	char* filePathC = (char*)malloc(sizeof(char) * charCount);

	for (int i = 0; i < charCount; i++)
	{
		char character = pwchar[i];

		*filePathC = character;

		filePathC += sizeof(char);

	}
	filePathC += '\0';

	filePathC -= (sizeof(char) * charCount);

	return filePathC;
}