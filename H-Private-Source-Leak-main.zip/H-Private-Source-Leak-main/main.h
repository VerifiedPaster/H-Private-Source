#include <list>
#include <string>
#include "offsets.h"
#include <string.h>
#include "xorst.h"
#include "functions.h"
#include <iostream>
#include "aimbot.h"
#include <random>

using namespace uee;

fvector PlayerFlyAddValue; //outside the loop
fvector PlayerFlySetLocation; //outside the loop


#define debug_weapons  true

#define M_PI 3.14159265358979323846

static float radius = 200.f;
static bool fill = false;
static bool Rainbow = false;
static bool toMouse = false;
int enemyID = 0;


float random()
{
	static std::random_device rd;
	static std::mt19937 gen(rd());
	static std::uniform_real_distribution<float> dis(0.0f, 1.0f);
	return dis(gen);
}


namespace g_loop {
	class g_fn {
	public:



		fvector2d head;
		fvector2d root;
		fvector2d pelvis;
		fvector2d left_shoulder;
		fvector2d left_elbow;
		fvector2d left_hand;
		fvector2d right_shoulder;
		fvector2d neck;

		fvector2d right_elbow;
		fvector2d right_hand;
		fvector2d left_knee;
		fvector2d left_foot;
		fvector2d right_knee;
		fvector2d right_foot;


		auto cache_entities() -> void {

			temporary_entity_list.clear();
			__int64 dynamic_uworld = offset::uworld + g_ptr->va_text;
			g_ptr->uworld = read <uintptr_t>(dynamic_uworld);
			g_ptr->game_instance = read <uintptr_t>(g_ptr->uworld + offset::game_instance);
			g_ptr->local_player = read <uintptr_t>(read <uintptr_t>(g_ptr->game_instance + offset::local_player));
			g_ptr->player_controller = read <uintptr_t>(g_ptr->local_player + offset::player_controller);
			g_ptr->acknowledged_pawn = read <uintptr_t>(g_ptr->player_controller + offset::acknowledged_pawn);
			g_ptr->skeletal_mesh = read <uintptr_t>(g_ptr->acknowledged_pawn + offset::skeletal_mesh);
			g_ptr->player_state = read <uintptr_t>(g_ptr->acknowledged_pawn + offset::player_state);
			g_ptr->root_component = read <uintptr_t>(g_ptr->acknowledged_pawn + offset::root_component);
			g_ptr->relative_location = read <fvector>(g_ptr->root_component + offset::relative_location);
			g_ptr->team_index = read <int>(g_ptr->player_state + offset::team_index);
			if (Misc::DeveloperMode)
			{
				std::cout << E(" uworld -> ") << g_ptr->uworld << std::endl;
				std::cout << E(" game_instance -> ") << g_ptr->game_instance << std::endl;
				std::cout << E(" local_player -> ") << g_ptr->local_player << std::endl;
				std::cout << E(" player_controller -> ") << g_ptr->player_controller << std::endl;
				std::cout << E(" acknowledged_pawn -> ") << g_ptr->acknowledged_pawn << std::endl;
				std::cout << E(" skeletal_mesh -> ") << g_ptr->skeletal_mesh << std::endl;
				std::cout << E(" player_state -> ") << g_ptr->player_state << std::endl;
				std::cout << E(" root_component -> ") << g_ptr->root_component << std::endl;
				std::cout << E(" relative_location.X -> ") << g_ptr->relative_location.x << std::endl;
				std::cout << E(" relative_location.Y -> ") << g_ptr->relative_location.y << std::endl;
				std::cout << E(" relative_location.Z -> ") << g_ptr->relative_location.z << std::endl;
				std::cout << E(" team_index -> ") << g_ptr->team_index << std::endl;

				system("cls");
			}

			bool inlobby;

			if (g_ptr->acknowledged_pawn == NULL)
			{
				inlobby = true;
			}
			else
			{
				inlobby = false;
			}


			if (!g_ptr->acknowledged_pawn)
			{
				Aimbot::in_lobby = true;
			}
			else
			{
				Aimbot::in_lobby = false;
			}

			if (g_ptr->acknowledged_pawn) {




				uint64_t player_weapon = read <uint64_t>(g_ptr->acknowledged_pawn + WeaponOffsets::CurrentWeapon);

				if (is_valid(player_weapon)) {

					uint64_t weapon_data = read <uint64_t>(player_weapon + WeaponOffsets::WeaponData);

					if (is_valid(weapon_data)) {

						uint64_t ftext_ptr = read <uint64_t>(weapon_data + WeaponOffsets::ItemName);

						if (is_valid(ftext_ptr)) {
							uint64_t ftext_data = read <uint64_t>(ftext_ptr + 0x28);
							int ftext_length = read <int>(ftext_ptr + 0x30);
							if (ftext_length > 0 && ftext_length < 50) {
								wchar_t* ftext_buf = new wchar_t[ftext_length];
								read1(ftext_data, ftext_buf, ftext_length * sizeof(wchar_t));
								std::wstring wstr_buf(ftext_buf);

								LocalPlayerWeapon = std::string(wstr_buf.begin(), wstr_buf.end());
								//std::cout << "\nLocalPlayerWeapon" << LocalPlayerWeapon << std::endl;

								wchar_t* WeaponName = ftext_buf;

								delete[] ftext_buf;
								if (Misc::g_weapon_cfg)
								{

									if (wcsstr(WeaponName, E(L"Assault Rifle")) || wcsstr(WeaponName, E(L"Havoc Suppressed Assault Rifle")) || wcsstr(WeaponName, E(L"Red-Eye Assault Rifle"))
										|| wcsstr(WeaponName, E(L"Suppressed Assault Rifle")) || wcsstr(WeaponName, E(L"Striker Burst Rifle")) || wcsstr(WeaponName, E(L"Burst Assault Rifle"))
										|| wcsstr(WeaponName, E(L"Ranger Assault Rifle")) || wcsstr(WeaponName, E(L"Flapjack Rifle")) || wcsstr(WeaponName, E(L"Heavy Assault Rifle"))
										|| wcsstr(WeaponName, E(L"MK-Seven Assault Rifle")) || wcsstr(WeaponName, E(L"MK-Alpha Assault Rifle")) || wcsstr(WeaponName, E(L"Combat Assault Rifle"))
										|| wcsstr(WeaponName, E(L"Nemesis AR")) || wcsstr(WeaponName, E(L"Ambush Striker AR")) || wcsstr(WeaponName, E(L"Striker AR")) || wcsstr(WeaponName, E(L"Huntress DMR"))
										|| wcsstr(WeaponName, E(L"Nemesis AR/Warforged Assault Rifle"))
										|| wcsstr(WeaponName, E(L"Warforged Assault Rifle"))
										|| wcsstr(WeaponName, E(L"Tactical Assault Rifle")) || wcsstr(WeaponName, E(L"Hammer Assault Rifle")) || wcsstr(WeaponName, E(L"Sideways Rifle")) || wcsstr(WeaponName, E(L"Makeshift Rifle")) || wcsstr(WeaponName, E(L"Drum Gun"))) {
										//HeldWeaponType = EFortWeaponType::Rifle;

										Aimbot::smooth = rifle::smooth;


									}
									if (wcsstr(WeaponName, E(L"Shotgun")) || wcsstr(WeaponName, E(L"Frenzy Auto Shotgun")) || wcsstr(WeaponName, E(L"Iron Warrior Hammer Pump Shogtun")) || wcsstr(WeaponName, E(L"Peter Griffin's Pump Shotgun")) || wcsstr(WeaponName, E(L"PETER GRIFFIN'S PUMP SHOTGUN"))) {
										//	HeldWeaponType = EFortWeaponType::Shotgun;

										Aimbot::smooth = shotgun::smooth;


									}
									if (wcsstr(WeaponName, E(L"Smg")) || wcsstr(WeaponName, E(L"Ambush Hyper SMG")) || wcsstr(WeaponName, E(L"Submachine Gun")) || wcsstr(WeaponName, E(L"Combat Smg")) || wcsstr(WeaponName, E(L"Pistol")) || wcsstr(WeaponName, E(L"Machine Smg"))
										|| wcsstr(WeaponName, E(L"Scoped Burst SMG")) || wcsstr(WeaponName, E(L"Hyper SMG")) || wcsstr(WeaponName, E(L"Thunger Burst SMG")) || wcsstr(WeaponName, E(L"Ranger Pistol"))) {
										//	HeldWeaponType = EFortWeaponType::Smg;

										Aimbot::smooth = smg::smooth;


									}
									if (wcsstr(WeaponName, E(L"Hunting Rifle")) || wcsstr(WeaponName, E(L"Heavy Sniper Rifle")) || wcsstr(WeaponName, E(L"Suppressed Sniper Rifle"))
										|| wcsstr(WeaponName, E(L"Storm Scout")) || wcsstr(WeaponName, E(L"Bolt-Action Sniper Rifle")) || wcsstr(WeaponName, E(L"Automatic Sniper Rifle"))
										|| wcsstr(WeaponName, E(L"DMR")) || wcsstr(WeaponName, E(L"Thermal DMR")) || wcsstr(WeaponName, E(L"Hunter Bolt-Action Sniper"))
										|| wcsstr(WeaponName, E(L"Reaper Sniper Rifle")) || wcsstr(WeaponName, E(L"Semi-Auto Sniper Rifle"))
										|| wcsstr(WeaponName, E(L"Crossbow")) || wcsstr(WeaponName, E(L"Mechanical Bow")) || wcsstr(WeaponName, E(L"Hand Cannon"))) {
										HeldWeaponType = EFortWeaponType::Sniper;

										Aimbot::smooth = sniper::smooth;


									}

								}
							}
						}
					}
				}
			}

			g_ptr->game_state = read <uintptr_t>(g_ptr->uworld + offset::game_state);
			g_ptr->player_array = read <uintptr_t>(g_ptr->game_state + offset::player_array);
			g_ptr->player_array_size = read <int>(g_ptr->game_state + (offset::player_array + sizeof(uintptr_t)));

			for (int i = 0; i < g_ptr->player_array_size; ++i) {

				auto player_state = read <uintptr_t>(g_ptr->player_array + (i * sizeof(uintptr_t)));
				auto current_actor = read <uintptr_t>(player_state + offset::pawn_private);
				auto root_component = read <uintptr_t>(current_actor + offset::root_component);
				auto relative_location = read <fvector>(root_component + offset::relative_location);
				auto pawn_private = read <uintptr_t>(player_state + offset::pawn_private);
				auto skeletalmesh = read <uintptr_t>(current_actor + offset::skeletal_mesh);
				if (!skeletalmesh) continue;
				auto base_bone = ue5->get_bone_3d(skeletalmesh, bone::Root);
				if (base_bone.x == 0 && base_bone.y == 0 && base_bone.z == 0) continue;
				if (!camera->in_screen(ue5->w2s(ue5->get_bone_3d(skeletalmesh, bone::Pelvis)))) continue;
				auto is_despawning = (read<char>(current_actor + 0x758) >> 3);
				if (is_despawning) continue;

				if (g_ptr->acknowledged_pawn)
				{
					auto team_index = read<int>(player_state + offset::team_index);
					if (g_ptr->team_index == team_index) continue;
					if (Misc::DeveloperMode)
					{
						std::printf(" GOT PAST TEAM CHECK ");

					}
				}

				entity cached_actors{ };
				cached_actors.entity = current_actor;
				cached_actors.skeletal_mesh = read<uintptr_t>(current_actor + offset::skeletal_mesh);;
				cached_actors.root_component = g_ptr->root_component;
				cached_actors.relative_location = relative_location;
				cached_actors.player_state = player_state;
				cached_actors.team_index = g_ptr->team_index;

				temporary_entity_list.push_back(cached_actors);
			}

			entity_list.clear();
			entity_list = temporary_entity_list;
			std::this_thread::sleep_for(std::chrono::milliseconds(150));

		}

		fvector2d head_box;
		fvector2d root_box;
		fvector2d root_box1;

		auto actor_loop() -> void {
			ImGui::PushFont(GameFont);
			ImDrawList* draw_list = ImGui::GetBackgroundDrawList();

			float target_dist = FLT_MAX;
			uintptr_t target_entity = NULL;

			ue5->get_camera();

			// Watermark + FPS
			if (Misc::Watermark) {
				char Watermark[255];
				sprintf_s(Watermark, skCrypt("CapWare\n"));
				ImColor Watermarkcolor[3] = {
					ImColor(255, 255, 255, 255),
					ImColor(255, 255, 255, 255),
					ImColor(255, 255, 255, 255)
				};
				DrawString(24, 10, 5, Watermarkcolor[(ImGui::GetFrameCount() / 60) % 3], false, true, Watermark);
			}
			if (Misc::fps && Misc::Watermark) {
				char fps[255];
				sprintf_s(fps, skCrypt("CapWare | [FPS %.3f]"), ImGui::GetIO().Framerate);
				ImColor Watermarkcolor[3] = {
					ImColor(255, 255, 255, 255),
					ImColor(255, 255, 255, 255),
					ImColor(255, 255, 255, 255)
				};
				DrawString(24, 10, 5, Watermarkcolor[(ImGui::GetFrameCount() / 60) % 3], false, true, fps);
			}
			if (Misc::Crosshair) {
				draw_list->AddLine(ImVec2(screen_width / 2 - 2, screen_height / 2), ImVec2(screen_width / 2 - 9, screen_height / 2), ImColor(0, 0, 0), 2);
				draw_list->AddLine(ImVec2(screen_width / 2 + 2, screen_height / 2), ImVec2(screen_width / 2 + 9, screen_height / 2), ImColor(0, 0, 0), 2);

				draw_list->AddLine(ImVec2(screen_width / 2, screen_height / 2 - 2), ImVec2(screen_width / 2, screen_height / 2 - 9), ImColor(0, 0, 0), 2);
				draw_list->AddLine(ImVec2(screen_width / 2, screen_height / 2 + 2), ImVec2(screen_width / 2, screen_height / 2 + 9), ImColor(0, 0, 0), 2);

			}

			const float centerWidth = screen_width / 2;
			const float centerHeight = screen_height / 2;
			//fov
			if (Aimbot::fov_circle)
			{
				h_custom(Aimbot::aim_fov, Fov::filled, Fov::RGB, false, Fov::rainbowSpeed);
			}

			for (auto& cached : entity_list) {

				auto root_bone = ue5->get_bone_3d(cached.skeletal_mesh, bone::Root);
				root = ue5->w2s(root_bone);
				root_box = ue5->w2s(fvector(root_bone.x, root_bone.y, root_bone.z + 30));
				root_box1 = ue5->w2s(fvector(root_bone.x, root_bone.y, root_bone.z - 15));
				auto head_bone = ue5->get_bone_3d(cached.skeletal_mesh, bone::Head);
				head = ue5->w2s(head_bone);
				head_box = ue5->w2s(fvector(head_bone.x, head_bone.y, head_bone.z + 15));

				float box_height = abs(head.y - root_box1.y);
				float box_width = box_height * 0.50f;

				float distance = camera_postion.location.distance(root_bone) / 100;
				auto pawn_private1 = read <uintptr_t>(g_ptr->player_state + offset::pawn_private);

				if (Aimbot::aimbot) {

					auto dx = head.x - (screen_width / 2);
					auto dy = head.y - (screen_height / 2);
					auto dist = sqrtf(dx * dx + dy * dy);

					if (Aimbot::visible_check) {
						if (ue5->is_visible(cached.skeletal_mesh)) {
							if (dist < Aimbot::aim_fov && dist < target_dist) {

								target_dist = dist;
								target_entity = cached.entity;
							}
						}
					}
					else {
						if (dist < Aimbot::aim_fov && dist < target_dist) {


							target_dist = dist;
							target_entity = cached.entity;
						}
					}
				}

				static ImColor downedcolor;
				static ImColor box_visible;
				static ImColor skeleton_visible;
				static ImColor name_visible;
				static ImColor snapline;
				static ImColor box_filled;
				ImColor visibleColor;


				downedcolor = ImGui::GetColorU32({ colors::skeleton_visible[0], colors::skeleton_visible[1], colors::skeleton_visible[2],  1.0f }); // Green for visible


				if (Aimbot::visible_check)
				{
					if (ue5->is_visible(cached.skeletal_mesh))
					{

						box_visible = ImGui::GetColorU32({ colors::box_visible[0], colors::box_visible[1], colors::box_visible[2],  1.0f }); // Green for visible
						box_filled = ImGui::GetColorU32({ colors::box_filled_visible[0], colors::box_filled_visible[1], colors::box_filled_visible[2], 0.2f }); // Green for visible
						skeleton_visible = ImGui::GetColorU32({ colors::skeleton_visible[0], colors::skeleton_visible[1], colors::skeleton_visible[2],  1.0f }); // Green for visible
						name_visible = ImGui::GetColorU32({ colors::username_visible[0], colors::username_visible[1], colors::username_visible[2],  1.0f }); // Green for visible
						snapline = ImGui::GetColorU32({ colors::skeleton_visible[0], colors::skeleton_visible[1], colors::skeleton_visible[2],  1.0f }); // Green for visible
					}
					else
					{
						box_visible = ImGui::GetColorU32({ colors::box_invisible[0], colors::box_invisible[1], colors::box_invisible[2],  1.0f }); // Red for non-visible
						box_filled = ImGui::GetColorU32({ colors::box_filled_invisible[0], colors::box_filled_invisible[1], colors::box_filled_invisible[2],  0.2f }); // Red for non-visible
						skeleton_visible = ImGui::GetColorU32({ colors::skeleton_invisible[0], colors::skeleton_invisible[1], colors::skeleton_invisible[2],  1.0f }); // Red for non-visible
						name_visible = ImGui::GetColorU32({ colors::username_invisible[0], colors::username_invisible[1], colors::username_invisible[2],  1.0f }); // Red for non-visible
						snapline = ImGui::GetColorU32({ colors::skeleton_visible[0], colors::skeleton_visible[1], colors::skeleton_visible[2],  1.0f }); // Red for non-visible
					}
				}

				// snapline
				if (Visuals::snapline)
				{
					draw_list->AddLine(ImVec2(screen_width / 2, 0), ImVec2(head_box.x, head_box.y), snapline, Misc::line_thick);

				}
				//box
				if (Visuals::enable_esp)
				{

					if (Visuals::Box_ESP)
					{
						if (Visuals::outline)
						{
							draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), head_box.y), ImVec2(root.x + (box_width / 2), head_box.y), ImColor(0, 0, 0), Misc::g_box_thick + 2);
							draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), head_box.y), ImVec2(head_box.x - (box_width / 2), root.y), ImColor(0, 0, 0), Misc::g_box_thick + 2);
							draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), root.y), ImVec2(root.x + (box_width / 2), root.y), ImColor(0, 0, 0), Misc::g_box_thick + 2);
							draw_list->AddLine(ImVec2(root.x + (box_width / 2), head_box.y), ImVec2(root.x + (box_width / 2), root.y), ImColor(0, 0, 0), Misc::g_box_thick + 2);
						}



						draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), head_box.y), ImVec2(root.x + (box_width / 2), head_box.y), box_visible, Misc::g_box_thick);
						draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), head_box.y), ImVec2(head_box.x - (box_width / 2), root.y), box_visible, Misc::g_box_thick);
						draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), root.y), ImVec2(root.x + (box_width / 2), root.y), box_visible, Misc::g_box_thick);
						draw_list->AddLine(ImVec2(root.x + (box_width / 2), head_box.y), ImVec2(root.x + (box_width / 2), root.y), box_visible, Misc::g_box_thick);
					}


					if (Visuals::Rounded_ESP)
					{
						if (Visuals::outline)
						{
							draw_list->AddRect(ImVec2(head_box.x - box_width / 2, head_box.y), ImVec2((head_box.x - box_width / 2) + box_width, head_box.y + box_height), ImColor(0, 0, 0), 10, Misc::g_box_thick + 2.0);
						}

						draw_list->AddRect(ImVec2(head_box.x - box_width / 2, head_box.y), ImVec2((head_box.x - box_width / 2) + box_width, head_box.y + box_height), box_visible, 10, Misc::g_box_thick);
					}

					if (Visuals::colorcornered)
					{
						if (Visuals::outline)
						{
							DrawCorneredBox(root.x - (box_width / 2), head_box.y, box_width, box_height, ImColor(0, 0, 0), Misc::g_box_thick + 2.0, 0, 0);
						}

						DrawCorneredBox(root.x - (box_width / 2), head_box.y, box_width, box_height, box_visible, Misc::g_box_thick, 0, 0);
					}

					if (Visuals::Filled_box)
					{
						if (Visuals::outline)
						{
							draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), head_box.y), ImVec2(root.x + (box_width / 2), head_box.y), ImColor(0, 0, 0), Misc::g_box_thick + 2);
							draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), head_box.y), ImVec2(head_box.x - (box_width / 2), root.y), ImColor(0, 0, 0), Misc::g_box_thick + 2);
							draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), root.y), ImVec2(root.x + (box_width / 2), root.y), ImColor(0, 0, 0), Misc::g_box_thick + 2);
							draw_list->AddLine(ImVec2(root.x + (box_width / 2), head_box.y), ImVec2(root.x + (box_width / 2), root.y), ImColor(0, 0, 0), Misc::g_box_thick + 2);
						}
						draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), head_box.y), ImVec2(root.x + (box_width / 2), head_box.y), box_filled, Misc::g_box_thick);
						draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), head_box.y), ImVec2(head_box.x - (box_width / 2), root.y), box_filled, Misc::g_box_thick);
						draw_list->AddLine(ImVec2(head_box.x - (box_width / 2), root.y), ImVec2(root.x + (box_width / 2), root.y), box_filled, Misc::g_box_thick);
						draw_list->AddLine(ImVec2(root.x + (box_width / 2), head_box.y), ImVec2(root.x + (box_width / 2), root.y), box_filled, Misc::g_box_thick);
						const float halfWidth = box_width / 2.0f;
						const ImVec2 topLeft(head_box.x - halfWidth, head_box.y);
						const ImVec2 bottomRight(root.x + halfWidth, root.y);
						draw_list->AddRectFilled(topLeft, bottomRight, box_filled, 0.0f, ImDrawCornerFlags_All);
					}



				}


				if (Misc::playercount)
				{
					char players_found[256];
					sprintf_s(players_found, (E("Players Rendered: %d")), entity_list.size());
					ImVec2 screenSize = ImGui::GetIO().DisplaySize;
					ImVec2 textSize = ImGui::CalcTextSize(players_found);
					ImGui::GetBackgroundDrawList()->AddText(ImVec2((screenSize.x - textSize.x) * 0.5f, 5), ImColor(255, 255, 255), players_found);

				}

				// Boxs esps
				// Weapon esp
				if (Visuals::weapon && Visuals::enable_esp)
				{
					if (g_ptr->acknowledged_pawn)
					{

						WeaponInformation held_weapon{ };

						uint64_t player_weapon = read <uint64_t>(cached.entity + WeaponOffsets::CurrentWeapon);

						if (is_valid(player_weapon)) {
							held_weapon.ammo_count = read <int32_t>(player_weapon + WeaponOffsets::AmmoCount);

							uint64_t weapon_data = read <uint64_t>(player_weapon + WeaponOffsets::WeaponData);

							if (is_valid(weapon_data)) {
								held_weapon.tier = read <BYTE>(weapon_data + WeaponOffsets::Tier);

								uint64_t ftext_ptr = read <uint64_t>(weapon_data + WeaponOffsets::ItemName);

								if (is_valid(ftext_ptr)) {
									uint64_t ftext_data = read <uint64_t>(ftext_ptr + 0x28); // 0x28 
									int ftext_length = read <int>(ftext_ptr + 0x30);
									if (ftext_length > 0 && ftext_length < 50) {
										wchar_t* ftext_buf = new wchar_t[ftext_length];

										read1(ftext_data, ftext_buf, ftext_length * sizeof(wchar_t));
										std::wstring wstr_buf(ftext_buf);
										held_weapon.weapon_name = std::string(wstr_buf.begin(), wstr_buf.end());
										delete[] ftext_buf;
									}
								}

							}

							WeaponInfo = held_weapon;

							std::string final = ("") + WeaponInfo.weapon_name + ("");

							ImVec2 TextSize = ImGui::CalcTextSize(final.c_str());

							ImVec2 text_size = ImGui::CalcTextSize(final.c_str());
							int add;
							if (Visuals::distance)
							{
								add = 25;
							}
							else
							{
								add = 5;
							}

							if (Visuals::weapon)
							{
								if (WeaponInfo.tier == 0)
								{
									if (strstr(WeaponInfo.weapon_name.c_str(), E("Pickaxe")) != nullptr)
									{
										DrawString(15, (root.x) - (TextSize.x / 2), (root.y + add), ImColor(255, 255, 255), false, true, final.c_str());
									}
									else
									{
										std::string fina1l = ("Building Plan");
										ImVec2 TextSiz1e = ImGui::CalcTextSize(fina1l.c_str());
										DrawString(15, (root.x) - (TextSiz1e.x / 2), (root.y + add), ImColor(255, 255, 255), false, true, fina1l.c_str());
									}

								}
								if (WeaponInfo.tier == 1)
								{
									DrawString(19, (root.x) - (TextSize.x / 2), (root.y + add), ImColor(170, 165, 169), false, true, final.c_str());

								}
								if (WeaponInfo.tier == 2)
								{
									DrawString(19, (root.x) - (TextSize.x / 2), (root.y + add), ImColor(30, 255, 0), false, true, final.c_str());

								}
								if (WeaponInfo.tier == 3)
								{
									DrawString(19, (root.x) - (TextSize.x / 2), (root.y + add), ImColor(0, 112, 221), false, true, final.c_str());

								}
								if (WeaponInfo.tier == 4)
								{
									DrawString(19, (root.x) - (TextSize.x / 2), (root.y + add), ImColor(163, 53, 238), false, true, final.c_str());

								}
								if (WeaponInfo.tier == 5)
								{
									DrawString(19, (root.x) - (TextSize.x / 2), (root.y + add), ImColor(255, 128, 0), false, true, final.c_str());

								}
								if (WeaponInfo.tier == 6)
								{
									DrawString(19, (root.x) - (TextSize.x / 2), (root.y + add), ImColor(255, 255, 0), false, true, final.c_str());

								}
							}
							else
							{
								if (WeaponInfo.tier == 0)
								{
									if (strstr(WeaponInfo.weapon_name.c_str(), E("Pickaxe")) != nullptr)
									{
										DrawString(19, (root.x) - (TextSize.x / 2), (root.y + add), visibleColor, false, true, final.c_str());
									}
									else
									{
										std::string fina1l = ("Building Plan");
										ImVec2 TextSiz1e = ImGui::CalcTextSize(fina1l.c_str());
										DrawString(19, (root.x) - (TextSiz1e.x / 2), (root.y + add), visibleColor, false, true, fina1l.c_str());
									}
								}
								else
								{
									DrawString(19, root.x - (text_size.x / 2), root.y + 20, visibleColor, false, true, final.c_str());
								}
							}
						}

					}
				}
				// Username + Kills
				if (Visuals::username && Visuals::enable_esp && Visuals::Kill && Visuals::enable_esp) // name + kill
				{
					std::string username_str = ue5->get_player_name(cached.player_state);
					int player_kill_count = read<int>(cached.player_state + 0x1224);
					std::string kills_display = " - Kills [" + std::to_string(player_kill_count) + "";

					ImVec2 text_size1 = ImGui::CalcTextSize(username_str.c_str());
					ImVec2 text_size2 = ImGui::CalcTextSize(kills_display.c_str());


					ImVec2 textPosition(text_size1.x, text_size2.y);

					std::string combinedText = username_str + "" + kills_display + "]";
					DrawString(20, head_box.x - 20 - (textPosition.x / 2), head_box.y - 20, ImColor(255, 255, 255), false, true, combinedText.c_str());
				}
				// Username
				else if (Visuals::username && Visuals::enable_esp) {

					std::string username_str = ue5->get_player_name(cached.player_state);
					if (!username_str.empty()) {
						std::string username_with_distance = username_str;

						ImVec2 text_size = ImGui::CalcTextSize(username_with_distance.c_str());
						float x_offset = text_size.x / 2.0f;

						DrawString(20, head_box.x - x_offset, head_box.y - 35, ImColor(255, 255, 255), false, true, username_with_distance.c_str());
					}
				}
				// Distance
				if (Visuals::distance && Visuals::enable_esp) {
					std::string distance_str = (std::string)("") + std::to_string((int)distance) + (std::string)("M");
					ImVec2 text_size = ImGui::CalcTextSize(distance_str.c_str());
					DrawString(20, root.x - (text_size.x / 2), root.y + 5, ImColor(255, 255, 255), false, true, distance_str.c_str());
				}
				//radar 
				if (Misc::Radar)
				{
					ue5->render_radar_main();
				}
				if (Misc::Radar)
				{
					ue5->add_to_radar(root_bone, 187, ue5->is_visible);
				}
				// Skeleton
				if (Visuals::skeleton && Visuals::enable_esp) {


				}
			}
			//Exploit
			
			if (Misc::FOVChanger)
			{
				if (uintptr_t PlayerCameraManager = read<uintptr_t>(g_ptr->player_controller + offset::PlayerCameraManager))
				{
					write<float>(PlayerCameraManager + offset::DefaultFOV + 0x4, Misc::DefaultFOV);
				}
			}
			
			
			



			if (Misc::AimWhileJumping) { //Allows you to ADS when You are in the Air
				write<bool>( g_ptr->acknowledged_pawn + 0x5638, true); //bADSWhileNotOnGround
			}
			else {
				write<bool>( g_ptr->acknowledged_pawn + 0x5638, false); //bADSWhileNotOnGround
			}



			ImGui::PopFont();

			// Prediction and aimbot
			if (target_entity && Aimbot::aimbot) {

				auto closest_mesh = read<uint64_t>(target_entity + offset::skeletal_mesh);
				auto root = read<uintptr_t>(target_entity + offset::root_component);
				fvector Velocity = read<fvector>(root + offset::velocity);


				fvector hitbox;			
				fvector2d hitbox_screen1;

				float projectileSpeed = 60000.f;
				float projectileGravityScale = 3.5f;



				switch (Aimbot::g_hitbox) {
				case 0:
					hitbox_screen1 = ue5->w2s(ue5->get_bone_3d(closest_mesh, bone::Head));
					hitbox = ue5->get_bone_3d(closest_mesh, bone::Head);;
					break;
				case 1:
					hitbox_screen1 = ue5->w2s(ue5->get_bone_3d(closest_mesh, bone::Neck));
					hitbox = ue5->get_bone_3d(closest_mesh, bone::Neck);;
					break;
				case 2:
					hitbox_screen1 = ue5->w2s(ue5->get_bone_3d(closest_mesh, bone::Chest));
					hitbox = ue5->get_bone_3d(closest_mesh, bone::Chest);;
					break;
				case 3:

					std::mt19937 rng(static_cast<unsigned int>(std::time(nullptr)));
					std::uniform_int_distribution<int> distribution(0, 3);

					int randomHitbox = distribution(rng);

					switch (randomHitbox)
					{

					case 0:

						hitbox_screen1 = ue5->w2s(ue5->get_bone_3d(closest_mesh, bone::Neck));
						hitbox = ue5->get_bone_3d(closest_mesh, bone::Neck);

						break;
					case 1:

						hitbox_screen1 = ue5->w2s(ue5->get_bone_3d(closest_mesh, bone::Chest));

						hitbox = ue5->get_bone_3d(closest_mesh, bone::Chest);

						break;
					case 2:

						hitbox_screen1 = ue5->w2s(ue5->get_bone_3d(closest_mesh, bone::RShoulder));

						hitbox = ue5->get_bone_3d(closest_mesh, bone::RShoulder);

						break;
					}
				}

				if (Aimbot::prediction) {
					if (EFortWeaponType::Sniper)
					{
						if (strstr(LocalPlayerWeapon.c_str(), ("Reaper Sniper Rifle"))) {


							projectileSpeed = 50000.0f;
							projectileGravityScale = 3.6f;
							std::cout << (skCrypt("Reaper Sniper Rifle\n ")) << std::flush;

							auto Distance = camera_postion.location.distance(hitbox);

							hitbox = ue5->Targer_Prediction(hitbox, Velocity, projectileSpeed, projectileGravityScale, Distance);

						}
					
						else if (strstr(LocalPlayerWeapon.c_str(), ("Huntress DMR")))
						{
							projectileSpeed = 96000.f;
							projectileGravityScale = 2.5f;
							std::cout << (skCrypt("Huntress DMR in HAND\n")) << std::flush;
							auto Distance = camera_postion.location.distance(hitbox);

							hitbox = ue5->Targer_Prediction(hitbox, Velocity, projectileSpeed, projectileGravityScale, Distance);
						}
						else if (strstr(LocalPlayerWeapon.c_str(), ("HandCannon")))
						{
							projectileSpeed = 60000.f;
							projectileGravityScale = 2.0f;
							std::cout << (skCrypt("HandCannon in HAND\n")) << std::flush;
							auto Distance = camera_postion.location.distance(hitbox);

							hitbox = ue5->Targer_Prediction(hitbox, Velocity, projectileSpeed, projectileGravityScale, Distance);
						}
						else if (strstr(LocalPlayerWeapon.c_str(), ("Warforged Assault Rifle")))
						{
							projectileSpeed = 80000.f;
							projectileGravityScale = 3.5f;
							std::cout << (skCrypt("Warforged Assault Rifle in HAND\n")) << std::flush;
							auto Distance = camera_postion.location.distance(hitbox);

							hitbox = ue5->Targer_Prediction(hitbox, Velocity, projectileSpeed, projectileGravityScale, Distance);
						}
						else if (strstr(LocalPlayerWeapon.c_str(), ("Nemesis AR")))
						{
							projectileSpeed = 80000.f;
							projectileGravityScale = 3.5f;
							std::cout << (skCrypt("Nemesis AR in HAND\n")) << std::flush;
							auto Distance = camera_postion.location.distance(hitbox);

							hitbox = ue5->Targer_Prediction(hitbox, Velocity, projectileSpeed, projectileGravityScale, Distance);
						}
						else if (strstr(LocalPlayerWeapon.c_str(), ("Harbinger SMG")))
						{
							projectileSpeed = 70000.f;
							projectileGravityScale = 3.0f;
							std::cout << (skCrypt("Harbinger SMG in HAND\n")) << std::flush;
							auto Distance = camera_postion.location.distance(hitbox);

							hitbox = ue5->Targer_Prediction(hitbox, Velocity, projectileSpeed, projectileGravityScale, Distance);
						}
						else if (strstr(LocalPlayerWeapon.c_str(), ("Hyper SMG")))
						{
							projectileSpeed = 70000.f;
							projectileGravityScale = 3.0f;
							std::cout << (skCrypt("Hyper SMG in HAND\n")) << std::flush;
							auto Distance = camera_postion.location.distance(hitbox);

							hitbox = ue5->Targer_Prediction(hitbox, Velocity, projectileSpeed, projectileGravityScale, Distance);
						}
						else if (strstr(LocalPlayerWeapon.c_str(), ("Thunder Burst SMG")))
						{
							projectileSpeed = 70000.f;
							projectileGravityScale = 3.0f;
							std::cout << (skCrypt("Thunder Burst SMG in HAND\n")) << std::flush;
							auto Distance = camera_postion.location.distance(hitbox);

							hitbox = ue5->Targer_Prediction(hitbox, Velocity, projectileSpeed, projectileGravityScale, Distance);
						}
						else if (strstr(LocalPlayerWeapon.c_str(), ("Ranger Pistol")))
						{
							projectileSpeed = 60000.f;
							projectileGravityScale = 2.0f;
							std::cout << (skCrypt("Ranger Pistol in HAND\n")) << std::flush;
							auto Distance = camera_postion.location.distance(hitbox);

							hitbox = ue5->Targer_Prediction(hitbox, Velocity, projectileSpeed, projectileGravityScale, Distance);
						}
					}
				}

				fvector2d hitbox_screen = ue5->w2s(hitbox);

				if (hitbox.x != 0 || hitbox.y != 0 && (get_cross_distance(hitbox.x, hitbox.y, screen_width / 2, screen_height / 2) <= Aimbot::aim_fov))
				{
					if (Aimbot::target_line) // Target Line
					{
						ImGui::GetForegroundDrawList()->AddLine(ImVec2(screen_width / 2, screen_height / 2), ImVec2(hitbox_screen.x, hitbox_screen.y), ImColor(255, 255, 255, 255), 1); // 2 size
					}
					if (Aimbot::target_text) // Target Text
					{
						DrawString(20, hitbox_screen.x - 6, hitbox_screen.y - 30, ImColor(119, 45, 132), true, true, E("[T]"));
					}
					{


						if (GetAsyncKeyState_Spoofed(Aimbot::aimkey))
							input->move(hitbox_screen);

					}
				}
			}
		}

	};
} static g_loop::g_fn* g_main = new g_loop::g_fn();