#include "main.h"
#include "icons.h"
#include <D3D11.h>
#include "ImGui/imgui_impl_dx11.h"
#include "icon.h"
#include "ImGui/imgui_internal.h"
#include "fonts.h"
#include "image.h"
#include "ImGui/image.h"
#include "ImGui/imgui_settings.h"
#include <D3DX11tex.h>
#include "SaveLoadConfig.hpp"
#include "menuDef.h"
#include "ImGui/font.h"
#include "ImGui/imgui_elements.h"

DWORD picker_flags = ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaPreview;

inline static int keystatus = 0;
inline static int realkey = 0;
inline static int realkey1 = 0;
inline static int keystatus1 = 0;
inline static int keystatus2 = 0;
inline static int keystatus3 = 0;
inline static int keystatus4 = 0;
inline static int keystatus5 = 0;


HWND window_handle;
ID3D11Device* d3d_device;
ID3D11DeviceContext* d3d_device_ctx;
IDXGISwapChain* d3d_swap_chain;
ID3D11RenderTargetView* d3d_render_target;
D3DPRESENT_PARAMETERS d3d_present_params;

namespace font
{
    ImFont* icomoon[14];
    ImFont* segue_semibold_tabs;
    ImFont* segue_semibold;
    ImFont* segue_bold;
}


namespace status
{
    inline ImVec4 normaltxt = ImColor(255, 255, 255, 255);
    inline ImVec4 Undetect = ImColor(0, 255, 0, 255);
    inline ImVec4 Updaiting = ImColor(255, 165, 0, 255);
    inline ImVec4 Down = ImColor(255, 0, 0, 255);
}





inline bool GetKey(int key)
{
    realkey = key;
    return true;
}
inline void ChangeKey(void* blank)
{
    keystatus = 1;
    while (true)
    {
        for (int i = 0; i < 0x87; i++)
        {
            if (GetAsyncKeyState_Spoofed(i) & 0x8000)
            {
                Aimbot::aimkey = i;
                keystatus = 0;
                return;
            }
        }
    }
}
inline void ChangeKey1(void* blank)
{
    keystatus5 = 1;
    while (true)
    {
        for (int i = 0; i < 0x87; i++)
        {
            if (GetAsyncKeyState(i) & 0x8000)
            {
                Aimbot::triggerkey = i;
                keystatus5 = 0;
                return;
            }
        }
    }
}
inline void DrawBox(float X, float Y, float W, float H, const ImU32& color, int thickness)
{
    ImGui::GetForegroundDrawList()->AddRect(ImVec2(X, Y), ImVec2(X + W, Y + H), ImGui::GetColorU32(color), thickness);
}
static const char* keyNames[] =
{

    "Keybind",
    "Left Mouse",
    "Right Mouse",
    "Cancel",
    "Middle Mouse",
    "Mouse 5",
    "Mouse 4",
    "",
    "Backspace",
    "Tab",
    "",
    "",
    "Clear",
    "Enter",
    "",
    "",
    "Shift",
    "Control",
    "Alt",
    "Pause",
    "Caps",
    "",
    "",
    "",
    "",
    "",
    "",
    "Escape",
    "",
    "",
    "",
    "",
    "Space",
    "Page Up",
    "Page Down",
    "End",
    "Home",
    "Left",
    "Up",
    "Right",
    "Down",
    "",
    "",
    "",
    "Print",
    "Insert",
    "Delete",
    "",
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
    "",
    "",
    "",
    "",
    "",
    "Numpad 0",
    "Numpad 1",
    "Numpad 2",
    "Numpad 3",
    "Numpad 4",
    "Numpad 5",
    "Numpad 6",
    "Numpad 7",
    "Numpad 8",
    "Numpad 9",
    "Multiply",
    "Add",
    "",
    "Subtract",
    "Decimal",
    "Divide",
    "F1",
    "F2",
    "F3",
    "F4",
    "F5",
    "F6",
    "F7",
    "F8",
    "F9",
    "F10",
    "F11",
    "F12",
};

//void RenderGlowingText(const char* text, ImVec4 color, ImVec4 glowColor, float glowSize) {
//    // Get the current ImGui window draw list
//    ImDrawList* drawList = ImGui::GetWindowDrawList();
//
//    // Get the text size
//    ImVec2 textSize = ImGui::CalcTextSize(text);
//
//    // Calculate the position for the text
//    ImVec2 textPos = ImGui::GetCursorScreenPos();
//
//    // Render the glowing part of the text
//    drawList->AddText(textPos, ImGui::ColorConvertFloat4ToU32(glowColor), text, 0, glowSize);
//
//    // Render the main text
//    drawList->AddText(textPos, ImGui::ColorConvertFloat4ToU32(color), text);
//}

inline static bool Items_ArrayGetter(void* data, int idx, const char** out_text)
{
    const char* const* items = (const char* const*)data;
    if (out_text)
        *out_text = items[idx];
    return true;
}
inline void HotkeyButton(int aimkey, void* changekey, int status)
{
    const char* preview_value = NULL;
    if (aimkey >= 0 && aimkey < IM_ARRAYSIZE(keyNames))
        Items_ArrayGetter(keyNames, aimkey, &preview_value);
    std::string aimkeys;
    if (preview_value == NULL)
        aimkeys = (E("Select Key"));
    else
        aimkeys = preview_value;

    if (status == 1)
    {

        aimkeys = (E("Press the Key"));
    }
    if (ImGui::CustomButton(aimkeys.c_str(), ImVec2(155, 40), NULL))
    {
        if (status == 0)
        {
            CreateThread(0, 0, (LPTHREAD_START_ROUTINE)changekey, nullptr, 0, nullptr);
        }
    }
}

namespace n_render {
    class c_render {
    public:


        auto imgui() -> bool {
            SPOOF_FUNC

                DXGI_SWAP_CHAIN_DESC swap_chain_description;
            ZeroMemory(&swap_chain_description, sizeof(swap_chain_description));
            swap_chain_description.BufferCount = 2;
            swap_chain_description.BufferDesc.Width = 0;
            swap_chain_description.BufferDesc.Height = 0;
            swap_chain_description.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
            swap_chain_description.BufferDesc.RefreshRate.Numerator = 60;
            swap_chain_description.BufferDesc.RefreshRate.Denominator = 1;
            swap_chain_description.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
            swap_chain_description.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
            swap_chain_description.OutputWindow = window_handle;
            swap_chain_description.SampleDesc.Count = 1;
            swap_chain_description.SampleDesc.Quality = 0;
            swap_chain_description.Windowed = 1;
            swap_chain_description.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
            D3D_FEATURE_LEVEL d3d_feature_lvl;
            const D3D_FEATURE_LEVEL d3d_feature_array[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
            D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, d3d_feature_array, 2, D3D11_SDK_VERSION, &swap_chain_description, &d3d_swap_chain, &d3d_device, &d3d_feature_lvl, &d3d_device_ctx);
            ID3D11Texture2D* pBackBuffer;
            d3d_swap_chain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
            d3d_device->CreateRenderTargetView(pBackBuffer, NULL, &d3d_render_target);
            pBackBuffer->Release();


            IMGUI_CHECKVERSION();
            ImGui::CreateContext();
            ImGuiIO& io = ImGui::GetIO(); (void)io;
            io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
            io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;
            ImFontConfig cfg;

            font::segue_semibold = io.Fonts->AddFontFromMemoryTTF(segue_semibold, sizeof(segue_semibold), 18.f, &cfg, io.Fonts->GetGlyphRangesCyrillic());
            font::segue_semibold_tabs = io.Fonts->AddFontFromMemoryTTF(segue_semibold, sizeof(segue_semibold), 15.f, &cfg, io.Fonts->GetGlyphRangesCyrillic());
            font::segue_bold = io.Fonts->AddFontFromMemoryTTF(segue_bold, sizeof(segue_bold), 18.f, &cfg, io.Fonts->GetGlyphRangesCyrillic());
            GameFont = io.Fonts->AddFontFromMemoryTTF(anton, sizeof(anton), 18.f, &cfg, io.Fonts->GetGlyphRangesCyrillic());

            for (int i = 15; i < 25; i++) font::icomoon[i] = io.Fonts->AddFontFromMemoryTTF(icomoon, sizeof(icomoon), i, &cfg, io.Fonts->GetGlyphRangesCyrillic());




            ImGui_ImplWin32_Init(window_handle);

            ImGui_ImplDX11_Init(d3d_device, d3d_device_ctx);



            d3d_device->Release();

            return true;
        }




        auto hijack() -> bool {

            window_handle = FindWindowA_Spoofed(E("CiceroUIWndFrame"), E("CiceroUIWndFrame")); // Overwolf / vs
            //window_handle = FindWindowA_Spoofed(E("Afx:00400000:20:00010003:00000000:00000000"), E("MSI Afterburner ")); // riva / vs
            //window_handle = FindWindowA_Spoofed ( E ("MedalOverlayClass" ), E ( "MedalOverlay" ) ); // Medal
            //window_handle = FindWindowA_Spoofed(E("CEF-OSC-WIDGET"), E("NVIDIA Geforce Overlay")); // Nvidia
            //window_handle = FindWindowA_Spoofed(E("GDI+ Hook Class"), E("GDI+ Window (FPSMonitor)")); // Monitor
            //window_handle = FindWindowA_Spoofed(E("GDI+ Hook Window Class"), E("GDI+ Window (obs64.exe)")); // 

            if (!window_handle)
            {
                MessageBoxA(0, skCrypt("{!} Overlay Failed. Contact Support with error {3}"), skCrypt(""), MB_ICONINFORMATION);
            }

            int WindowWidth = GetSystemMetrics(SM_CXSCREEN);
            int WindowHeight = GetSystemMetrics(SM_CYSCREEN);

            if (!SetWindowPos_Spoofed(window_handle, HWND_TOPMOST, 0, 0, WindowWidth, WindowHeight, SWP_SHOWWINDOW))
            {
                return false;
            }

            if (!SetLayeredWindowAttributes_Spoofed(window_handle, RGB(0, 0, 0), 255, LWA_ALPHA))
            {
                return false;
            }

            if (!SetWindowLongA_Spoofed(window_handle, GWL_EXSTYLE, GetWindowLong(window_handle, GWL_EXSTYLE) | WS_EX_TRANSPARENT))
            {
                return false;
            }

            MARGINS Margin = { -1 };
            if (FAILED(DwmExtendFrameIntoClientArea(window_handle, &Margin)))
            {
                return false;
            }

            ShowWindow_Spoofed(window_handle, SW_SHOW);

            UpdateWindow_Spoofed(window_handle);

            ShowWindow_Spoofed(window_handle, SW_HIDE);

            return true;
        }


        DWORD window_flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBringToFrontOnFocus;


        auto menu() -> void
        {
            if (GetAsyncKeyState_Spoofed(VK_INSERT) & 1)
                Misc::enable_menu = !Misc::enable_menu;
            if (Misc::enable_menu)
            {
                ImGuiStyle* style = &ImGui::GetStyle();

                static float color[4] = { 124 / 255.f, 103 / 255.f, 255 / 255.f, 1.f };
                c::accent = { color[0], color[1], color[2], 1.f };

                style->WindowPadding = ImVec2(0, 0);
                style->ItemSpacing = ImVec2(20, 20);
                style->WindowBorderSize = 0;
                style->ScrollbarSize = 6.f;
                ImGui::SetNextWindowSizeConstraints(ImVec2(c::bg::size), ImGui::GetIO().DisplaySize);
                ImGui::Begin("IMGUI", nullptr, window_flags);
                {
                    const ImVec2& pos = ImGui::GetWindowPos();
                    const ImVec2& region = ImGui::GetContentRegionMax();
                    const ImVec2& spacing = style->ItemSpacing;

                    ImGui::GetWindowDrawList()->AddRectFilled(pos, pos + ImVec2(region), ImGui::GetColorU32(c::bg::background), c::bg::rounding);

                    ImGui::GetWindowDrawList()->AddRectFilledMultiColor(pos + ImVec2(0, 50), pos + ImVec2(region.x, 65), ImGui::GetColorU32(c::bg::shadow), ImGui::GetColorU32(c::bg::shadow), ImGui::GetColorU32(c::bg::shadow, 0.f), ImGui::GetColorU32(c::bg::shadow, 0.f));
                    ImGui::GetWindowDrawList()->AddRectFilledMultiColor(pos + ImVec2(180, 50), pos + ImVec2(195, region.y), ImGui::GetColorU32(c::bg::shadow), ImGui::GetColorU32(c::bg::shadow, 0.f), ImGui::GetColorU32(c::bg::shadow, 0.f), ImGui::GetColorU32(c::bg::shadow));

                    ImGui::GetWindowDrawList()->AddText(pos + ImVec2(50 - ImGui::CalcTextSize(E("CapWare Public")).y, 50 - ImGui::CalcTextSize(E("CapWare Public")).y) / 2, ImGui::GetColorU32(c::text::text), E("CapWare Public"));
                    //  ImGui::GetWindowDrawList()->AddText(pos + ImVec2(region.x - ((195 + 64) + (35 / 2) + ImGui::CalcTextSize("UD").x), (50 - ImGui::CalcTextSize("UD").y) / 2), ImGui::GetColorU32(c::accent, 0.2f), "UD");

                     // ImGui::GetWindowDrawList()->AddText(pos + ImVec2(region.x - (54 - ImGui::CalcTextSize("UD").y), (50 - ImGui::CalcTextSize("UD").y) / 2), ImGui::GetColorU32(c::accent), "UD");
                    ImGui::SetCursorPos(ImVec2(region.x - (195 + 57), (50 - 38) / 2));


                    ImGui::GetWindowDrawList()->AddRectFilled(pos + ImVec2(region.x - 53, 0), pos + ImVec2(region.x - 50, 50), ImGui::GetColorU32(c::bg::background), 0.f);
                    ImGui::GetWindowDrawList()->AddRectFilled(pos + ImVec2(region.x - (195 + 64), 0), pos + ImVec2(region.x - (195 + 61), 50), ImGui::GetColorU32(c::bg::background), 0.f);

                    static int tabs = 0;

                    ImGui::SetCursorPos(ImVec2(0, 50) + spacing);
                    ImGui::BeginChild("JUST TAB", ImVec2(180, region.y - (50 + spacing.y)) - spacing, NULL);
                    {

                        ImGui::CustomBeginChild("d", E("Aimbot"), ImVec2((180 - spacing.x * 2), 0), true, true, NULL);
                        {

                            if (ImGui::Tab(0 == tabs, E("General"), ImVec2(ImGui::GetContentRegionMax().x - style->WindowPadding.x, 30))) tabs = 0;

                            if (ImGui::Tab(1 == tabs, E("Config"), ImVec2(ImGui::GetContentRegionMax().x - style->WindowPadding.x, 30))) tabs = 1;

                        }
                        ImGui::CustomEndChild();

                        ImGui::CustomBeginChild("d", E("Visuals"), ImVec2((180 - spacing.x * 2), 0), true, true, NULL);
                        {

                            if (ImGui::Tab(2 == tabs, E("ESP"), ImVec2(ImGui::GetContentRegionMax().x - style->WindowPadding.x, 30))) tabs = 2;

                            if (ImGui::Tab(3 == tabs, E("Color"), ImVec2(ImGui::GetContentRegionMax().x - style->WindowPadding.x, 30))) tabs = 3;

                        }
                        ImGui::CustomEndChild();

                        ImGui::CustomBeginChild("d", E("Misc"), ImVec2((180 - spacing.x * 2), 0), true, true, NULL);
                        {
                            
                            if (ImGui::Tab(4 == tabs, E("Settings"), ImVec2(ImGui::GetContentRegionMax().x - style->WindowPadding.x, 30))) tabs = 4;

                            //if (ImGui::Tab(5 == tabs, "Config (SOON)", ImVec2(ImGui::GetContentRegionMax().x - style->WindowPadding.x, 30))) tabs = 5;

                        }
                        ImGui::CustomEndChild();

                    }
                    ImGui::EndChild();

                    static float tab_alpha = 0.f; /* */ static float tab_add; /* */ static int active_tab = 0;

                    tab_alpha = ImClamp(tab_alpha + (4.f * ImGui::GetIO().DeltaTime * (tabs == active_tab ? 1.f : -1.f)), 0.f, 1.f);
                    tab_add = ImClamp(tab_add + (std::round(350.f) * ImGui::GetIO().DeltaTime * (tabs == active_tab ? 1.f : -1.f)), 0.f, 1.f);

                    if (tab_alpha == 0.f && tab_add == 0.f) active_tab = tabs;

                    ImGui::SetCursorPos(ImVec2(180, 50) + spacing);

                    ImGui::BeginChild("JUST CHILD", ImVec2(region.x - 180, region.y - (50 + spacing.y)) - spacing);
                    {
                        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, tab_alpha * ImGui::GetStyle().Alpha);
                        //aimbot
                        if (active_tab == 0)
                        {
                            ImGui::BeginGroup();
                            {
                                ImGui::CustomBeginChild("", E("General"), ImVec2((region.x - (180 + spacing.x * 3)) / 2, 0), false, NULL, NULL);
                                {
                                    ImGui::Checkbox(E("Enable aimbot"), &Aimbot::aimbot);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Visible Check"), &Aimbot::visible_check);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Fov Circle"), &Aimbot::fov_circle);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Target Line"), &Aimbot::target_line);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Prediction"), &Aimbot::prediction);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("triggerbot"), &Aimbot::triger);
                                }
                                ImGui::CustomEndChild();
                            }
                            ImGui::EndGroup();

                            ImGui::SameLine();

                            ImGui::BeginGroup();
                            {
                                ImGui::CustomBeginChild("", E("Settings"), ImVec2((region.x - (180 + spacing.x * 3)) / 2, 0), false, NULL, NULL);
                                {

                                    ImGui::KnobInt(E("FOV"), &Aimbot::aim_fov, 50, 200, NULL, NULL);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("FOV RGB"), &Fov::RGB);
                                    ImGui::Separator();
                                    ImGui::KnobInt(E("RGB Speed"), &Fov::rainbowSpeed, 1, 10, NULL, NULL);
                                    ImGui::Separator();
                                    ImGui::KnobInt(E("Smooth"), &Aimbot::smooth, 1, 10, NULL, NULL);
                                    ImGui::Separator();
                                    HotkeyButton(Aimbot::aimkey, ChangeKey, keystatus);
                                    ImGui::Separator();
                                    HotkeyButton(Aimbot::triggerkey, ChangeKey1, keystatus5);


                                }
                                ImGui::CustomEndChild();

                            }
                            ImGui::EndGroup();


                        }
                        //Weapon
                        else if (active_tab == 1)
                        {
                            ImGui::BeginGroup();
                            {
                                ImGui::CustomBeginChild("", E("Weapon config"), ImVec2((region.x - (180 + spacing.x * 3)) / 2, 0), false, NULL, NULL);
                                ImGui::Checkbox(E("Weapon config"), &Misc::g_weapon_cfg);
                                ImGui::Separator();
                                ImGui::KnobInt(E("Shotgun Smooth"), &shotgun::smooth, 1, 10, NULL, NULL);
                                ImGui::Separator();
                                ImGui::KnobInt(E("Smg Smooth"), &smg::smooth, 1, 10, NULL, NULL);
                                ImGui::Separator();
                                ImGui::KnobInt(E("Rifle Smooth"), &rifle::smooth, 1, 10, NULL, NULL);
                                ImGui::Separator();
                                ImGui::KnobInt(E("Sniper Smooth"), &sniper::smooth, 1, 10, NULL, NULL);
                            }
                            ImGui::CustomEndChild(); {
                            }
                            ImGui::EndGroup();
                            ImGui::SameLine();
                        }
                        //Esp
                        else if (active_tab == 2)
                        {
                            ImGui::BeginGroup();
                            {
                                ImGui::CustomBeginChild("", E("General"), ImVec2((region.x - (180 + spacing.x * 3)) / 2, 0), false, NULL, NULL);
                                {
                                    ImGui::Checkbox(E("Enable ESP"), &Visuals::enable_esp);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("2D Box"), &Visuals::Box_ESP);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Cornered Box"), &Visuals::colorcornered);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Filled Box"), &Visuals::Filled_box);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Skeleton"), &Visuals::skeleton);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Snapline"), &Visuals::snapline);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Outline"), &Visuals::outline);
                                }
                                ImGui::CustomEndChild();
                            }
                            ImGui::EndGroup();

                            ImGui::SameLine();

                            ImGui::BeginGroup();
                            {
                                ImGui::CustomBeginChild("", E("Player"), ImVec2((region.x - (180 + spacing.x * 3)) / 2, 0), false, NULL, NULL);
                                {
                                    ImGui::Checkbox(E("Username"), &Visuals::username);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Weapon"), &Visuals::weapon);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Distance"), &Visuals::distance);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Player Kills"), &Visuals::Kill);
                                }
                                ImGui::CustomEndChild();

                                ImGui::BeginGroup();
                                {
                                    ImGui::CustomBeginChild("", E("Thickness"), ImVec2((region.x - (180 + spacing.x * 3)) / 2, 0), false, NULL, NULL);
                                    {
                                        ImGui::KnobInt(E("Box Thick"), &Misc::g_box_thick, 1, 10, NULL, NULL);
                                        ImGui::Separator();
                                        ImGui::KnobInt(E("Skeleton Thick"), &Visuals::skeleton_thick, 1, 10, NULL, NULL);
                                        ImGui::Separator();


                                    }
                                    ImGui::CustomEndChild();

                                }
                                ImGui::EndGroup();

                            }
                            ImGui::EndGroup();


                        }
                        //colors
                        else if (active_tab == 3)
                        {
                            ImGui::BeginGroup();
                            {
                                ImGui::CustomBeginChild("", "Colors", ImVec2((region.x - (180 + spacing.x * 3)) / 2, 0), false, NULL, NULL);
                                {
                                    ImGui::ColorEdit4(E("Box visible"), colors::box_visible, picker_flags);
                                    ImGui::Separator();
                                    ImGui::ColorEdit4(E("Box Invisible"), colors::box_invisible, picker_flags);
                                    ImGui::Separator();
                                    ImGui::ColorEdit4(E("Skeleton visible"), colors::skeleton_visible, picker_flags);
                                    ImGui::Separator();
                                    ImGui::ColorEdit4(E("Skeleton Invisible"), colors::skeleton_invisible, picker_flags);
                                    
                                }
                                ImGui::CustomEndChild();
                            }
                            ImGui::EndGroup();

                        }
                        //misc
                        else if (active_tab == 4)
                        {
                            ImGui::BeginGroup();
                            {
                                ImGui::CustomBeginChild("", "Misc", ImVec2((region.x - (180 + spacing.x * 3)) / 2, 0), false, NULL, NULL);
                                {
                                    ImGui::Checkbox(E("Crosshair"), &Misc::Crosshair);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("FPS"), &Misc::fps);
                                    ImGui::Separator();
                                    ImGui::Checkbox(E("Playercount"), &Misc::playercount);
                                    ImGui::Separator();
                                    //ImGui::Checkbox(E("magicbullet"), &Misc::magicbullet);
                                    //ImGui::Separator();
                                    ImGui::Checkbox(E("Radar"), &Misc::Radar);
                                    //ImGui::Separator();
                                    //ImGui::Checkbox(E("FovChanger"), &Misc::FOVChanger);
                                    //ImGui::Separator();
                                    //ImGui::KnobFloat(E("Fov"), &Misc::DefaultFOV, 50, 175, NULL, NULL);
                                    //ImGui::Separator();
                                    //ImGui::Checkbox(E("PlayerFly"), &Misc::PlayerFly);
                                    //ImGui::Checkbox("ClientSpinbot", &Misc::ClientSpinbot);
                                   // ImGui::Checkbox(E("AimWhileJumping"), &Misc::AimWhileJumping);
                                   // ImGui::Checkbox("RapidFire", &Misc::RapidFire);

                                }
                                ImGui::CustomEndChild();
                            }
                            ImGui::EndGroup();

                            ImGui::SameLine();

                            ImGui::BeginGroup();
                            {
                                ImGui::CustomBeginChild("", E("Cheat Status"), ImVec2((region.x - (180 + spacing.x * 3)) / 2, 0), false, NULL, NULL);
                                {
                                    ImGui::TextColored(status::normaltxt, E("Cheat Status:"));
                                    ImGui::SameLine();
                                    ImGui::TextColored(status::Undetect, E("Undetected On BE | EAC")); 
                                    //ImGui::Checkbox("RapidFire", &Misc::Speedhack);
                                }
                                ImGui::CustomEndChild();

                            }
                            ImGui::EndGroup();

                        }


                        ImGui::PopStyleVar();
                    }
                    ImGui::EndChild();

                }
                ImGui::End();

            }
        }

        // menu finish 






        auto draw() -> void {

            ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 0.f);

            ImGui::StyleColorsDark();


            ImGui_ImplDX11_NewFrame();
            ImGui_ImplWin32_NewFrame();
            ImGui::NewFrame();

            g_main->actor_loop();

            menu();

            ImGui::Render();
            const float clear_color_with_alpha[4] = { clear_color.x * clear_color.w, clear_color.y * clear_color.w, clear_color.z * clear_color.w, clear_color.w };
            d3d_device_ctx->OMSetRenderTargets(1, &d3d_render_target, nullptr);
            d3d_device_ctx->ClearRenderTargetView(d3d_render_target, clear_color_with_alpha);
            ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

            d3d_swap_chain->Present(1, 0);

        }

        auto render() -> bool {
            SPOOF_FUNC

                static RECT rect_og;
            MSG msg = { NULL };
            ZeroMemory(&msg, sizeof(MSG));

            while (msg.message != WM_QUIT)
            {

                UpdateWindow_Spoofed(window_handle);
                ShowWindow_Spoofed(window_handle, SW_SHOW);

                if (PeekMessageA_Spoofed(&msg, window_handle, 0, 0, PM_REMOVE))
                {
                    TranslateMessage_Spoofed(&msg);
                    DispatchMessage(&msg);
                }

                ImGuiIO& io = ImGui::GetIO();
                io.ImeWindowHandle = window_handle;
                io.DeltaTime = 1.0f / 60.0f;


                POINT p_cursor;
                GetCursorPos(&p_cursor);
                io.MousePos.x = p_cursor.x;
                io.MousePos.y = p_cursor.y;

                if (GetAsyncKeyState_Spoofed(VK_LBUTTON)) {
                    io.MouseDown[0] = true;
                    io.MouseClicked[0] = true;
                    io.MouseClickedPos[0].x = io.MousePos.x;
                    io.MouseClickedPos[0].x = io.MousePos.y;
                }
                else
                    io.MouseDown[0] = false;

                draw();

            }
            ImGui_ImplDX11_Shutdown();
            ImGui_ImplWin32_Shutdown();
            ImGui::DestroyContext();

            DestroyWindow(window_handle);

            return true;

        }

    };
} static n_render::c_render* render = new n_render::c_render();