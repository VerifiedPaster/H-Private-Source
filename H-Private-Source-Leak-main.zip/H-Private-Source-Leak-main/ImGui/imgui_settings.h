#include "imgui.h"

namespace c {

    extern ImVec4 accent;

    namespace bg {
        extern ImVec4 background;
        extern ImVec4 shadow;
        extern ImVec4 border;
        extern ImVec2 size;
        extern float rounding;
    }

    namespace child {
        extern ImVec4 background;
        extern ImVec4 stroke;
        extern ImVec4 cap;
        extern float rounding;
    }

    namespace slider {
        extern ImVec4 background;
        extern ImVec4 scalar;
    }

    namespace checkbox {
        extern ImVec4 background;
    }

    namespace button {
        extern ImVec4 background;
        extern float rounding;
    }

    namespace picker {
        extern ImVec4 background;
        extern float rounding;
    }

    namespace input {
        extern ImVec4 background;
        extern float rounding;
    }

    namespace separator {
        extern ImVec4 line;
    }

    namespace keybind {
        extern ImVec4 background;
        extern float rounding;
    }

    namespace tabs {
        extern ImVec4 background;
        extern ImVec4 button;
        extern float rounding;
    }

    namespace text {
        extern ImVec4 text_active;
        extern ImVec4 checkbox_active;
        extern ImVec4 text_hov;
        extern ImVec4 text;
    }

}
