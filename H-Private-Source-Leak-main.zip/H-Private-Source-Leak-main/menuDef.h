#pragma once
#include <iostream>
#include <string>

//#include "render.h"
fvector p;

void SimpleBox(int x, int y, ImColor color, const char* str, const char* key, bool v)
{
	ImFont a;
	std::string utf_8_2 = str;
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 15, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 15, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 15, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 15, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 15, p.y + y + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(color)), utf_8_2.c_str());

	std::string utf_8_22 = key;
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 - 5, p.y + y + 1 - 6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_22.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 - 5, p.y + y - 1 - 6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_22.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 - 5, p.y + y - 1 - 6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_22.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 - 5, p.y + y + 1 - 6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_22.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 5, p.y + y - 6), ImGui::ColorConvertFloat4ToU32(ImVec4(color)), utf_8_22.c_str());

	if (v) {
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 160, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), "ON");
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 160, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), "ON");
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 160, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), "ON");
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 160, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), "ON");
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 160, p.y + y - 6), ImGui::ColorConvertFloat4ToU32(ImColor(0, 255, 0, 255)), "ON");

	}
	if (!v) {
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 160, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), "OFF");
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 160, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), "OFF");
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 160, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), "OFF");
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 160, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), "OFF");
		ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 160, p.y + y - 6), ImGui::ColorConvertFloat4ToU32(ImColor(255, 0, 0, 255)), "OFF");
	}


	//Draw::BackgroundFilledRBG(p.x + x, p.y + y, 15, 10, ImColor(0, 255, 150, 255))

}

void SimpleText(int x, int y, ImColor color, const char* str)
{
	ImFont a;
	std::string utf_8_2 = str;
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 15, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 15, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 15, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 15, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 15, p.y + y + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(color)), utf_8_2.c_str());
}

void SimpleBoxValue(int x, int y, ImColor color, const char* str, const char* key, int v)
{
	ImFont a;
	std::string utf_8_2 = str;
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 15, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 15, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 15, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 15, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_2.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 15, p.y + y + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(color)), utf_8_2.c_str());

	std::string utf_8_22 = key;
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 - 5, p.y + y + 1 - 6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_22.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 - 5, p.y + y - 1 - 6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_22.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 - 5, p.y + y - 1 - 6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_22.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 - 5, p.y + y + 1 - 6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), utf_8_22.c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 5, p.y + y - 6), ImGui::ColorConvertFloat4ToU32(ImVec4(color)), utf_8_22.c_str());

	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 160, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), std::to_string(v).c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 160, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), std::to_string(v).c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 1 + 160, p.y + y - 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), std::to_string(v).c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x - 1 + 160, p.y + y + 1 + -6), ImGui::ColorConvertFloat4ToU32(ImVec4(0, 0, 0, 1)), std::to_string(v).c_str());
	ImGui::GetBackgroundDrawList()->AddText(ImVec2(p.x + x + 160, p.y + y - 6), ImGui::ColorConvertFloat4ToU32(ImColor(255, 0, 0, 255)), std::to_string(v).c_str());
	//Draw::BackgroundFilledRBG(p.x + x, p.y + y, 15, 10, ImColor(0, 255, 150, 255))

}