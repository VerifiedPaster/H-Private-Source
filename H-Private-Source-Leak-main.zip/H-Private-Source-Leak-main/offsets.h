enum bone : int {
	Head = 110,
	Neck = 67,
	Chest = 66,
	Pelvis = 2,
	LShoulder = 9,
	RShoulder = 38,
	LElbow = 10,
	RElbow = 39,
	LHand = 33, 
	RHand = 62, 
	LHip = 71,
	RHip = 78,
	LFoot = 73,
	RFoot = 80,
	LKnee = 72,
	RKnee = 79,
	LHeel = 86,
	RHeel = 87,
	LToe = 76,
	RToe = 83,
	Root = 0
};




enum offset {
	uworld = 0x117105C8, //
	game_instance = 0x1D8,//
	game_state = 0x160,//
	local_player = 0x38,//
	player_controller = 0x30,//
	acknowledged_pawn = 0x338, // localpawn
	skeletal_mesh = 0x318,//
	player_state = 0x2B0,
	PlayerCameraManager = 0x348,
	DefaultFOV = 0x2A4,
	root_component = 0x198,
	bone_array = 0x5B8,
	velocity = 0x168,//
	relative_location = 0x120,
	relative_rotation = 0x138,
	team_index = 0x1211,//
	player_array = 0x2A8,
	pawn_private = 0x308,//
	component_to_world = 0x1c0, // C2w
	b_Allow_Targeting = 0xd3,
	location_under_reticle = 0x2530,
	// visible check
	LAST_SUMBIT_TIME = 0x2E8,
	LAST_SUMBIT_TIME_ON_SCREEN = 0x2F0,
};
enum WeaponOffsets {
	CurrentWeapon = 0xA68,
	AmmoCount = 0xEEC,
	WeaponData = 0x510,
	Tier = 0x9A,
	ItemName = 0x40,
};



namespace windef {
	DWORD ScreenCenterX;
}

